using System;
using System.Collections;
using System.IO;
using System.Text;

namespace Retrospec.IsoConverter
{
	/// <summary>
	/// Converts Ultimate Isometric code
	/// </summary>

	public class IsoData
	{
		public ArrayList Rooms=new ArrayList();
		private StreamWriter debug=null;
		public string AdditionalLocation;

		public bool UsingBlockExtension=false;	 //row 4
		public bool UsingControlExtension=false; //row 5
		public int BlockExtensionCode;
		public int BlockExtensionOffset;
		public int ControlExtensionCode;
		public ArrayList LocationData=new ArrayList();
		public ArrayList ObjectData=new ArrayList();
		public ArrayList RoomSizes=new ArrayList();
		public ArrayList BlockData=new ArrayList();
		public ArrayList BackgroundData=new ArrayList();
		public ArrayList DefinedBlocks=new ArrayList();
		public ArrayList Specials=new ArrayList();
		public string Filename;
		public string Prefixname;
		public int MapWidth;
		public bool DoingTwoByteBackground;
		public int OriginalLocationDataSize;
		public int CurrentLocationDataSize;

		public BlockDescriptor FindBlockFromNumber(int btype,int numberToFind)
		{
			foreach(BlockDescriptor mybd in DefinedBlocks)
				if(mybd.Number==numberToFind && mybd.Type==btype) return mybd;

			return (BlockDescriptor)DefinedBlocks[0];
		}
		public BlockDescriptor FindBlockFromString(int btype,string NameToFind)
		{
			foreach(BlockDescriptor mybd in DefinedBlocks)
				if(mybd.Name==NameToFind && mybd.Type==btype) return mybd;

			return (BlockDescriptor)DefinedBlocks[0];
		}

		public void LoadData(string file,string prefixname)
		{
			LoadData(file,prefixname,"");
		}
		
		public void LoadData(string file,string prefixname,string additionalLocation)
		{
			//populate data
			Filename=file;
			Prefixname=prefixname;
			LocationData.Clear();
			ObjectData.Clear();
			RoomSizes.Clear();
			BlockData.Clear();
			BackgroundData.Clear();
			DefinedBlocks.Clear();
			Specials.Clear();

			char[] bob2=",".ToCharArray();
			string lineread;
			string DefaultText="";
			StreamReader sr;

			//using normal map or additional map
			AdditionalLocation=additionalLocation;
			if(additionalLocation=="")
			{
				//normal
				sr=new StreamReader(this.Filename);
				//first line - locations
				lineread=sr.ReadLine();
			}
			else
			{
				//user file
				sr=new StreamReader("maps\\"+prefixname+"_map_user.txt");
				while((lineread=sr.ReadLine()) !=null)
				{
					string[] LocationDataString2=lineread.Split(bob2);
					if(LocationDataString2[0]!="")
					{
						if(LocationDataString2[0]==additionalLocation)
						{
							foreach(string a in LocationDataString2)
							{
								if(a!=additionalLocation) DefaultText+=(a+",");
							}
							if(DefaultText.EndsWith(",")) DefaultText=DefaultText.TrimEnd(bob2);
							break;
						}
					}
				}
				if(DefaultText=="") 
				{
					return;
				}
				sr.Close();
				//get back to original map file and skip first line
				sr=new StreamReader(this.Filename);
				//first line - locations
				lineread=sr.ReadLine();
				OriginalLocationDataSize=lineread.Split(bob2).Length;
				lineread=DefaultText;
				CurrentLocationDataSize=lineread.Split(bob2).Length;
			}
			
			string[] LocationDataString=lineread.Split(bob2);
			foreach(string element in LocationDataString)
				LocationData.Add(Convert.ToInt32(element,16));

			//second line - object data
			lineread=sr.ReadLine();
			string[] ObjectDataString=lineread.Split(bob2);
			foreach(string element in ObjectDataString)
				ObjectData.Add(Convert.ToInt32(element,16));

			//third line - room sizes
			lineread=sr.ReadLine();
			string[] RoomDataString=lineread.Split(bob2);
			RoomSize crs;
			for(int i=0;i<RoomDataString.Length;i+=3)
			{
				crs=new RoomSize();
				crs.x=Convert.ToInt32(RoomDataString[i],16);
				crs.y=Convert.ToInt32(RoomDataString[i+1],16);
				crs.z=Convert.ToInt32(RoomDataString[i+2],16);
				crs.description="x:" + (crs.x/8) + " y:" + (crs.y/8) + " z:" + crs.z/16;
				RoomSizes.Add(crs);
			}

			//fourth line - block extension
			lineread=sr.ReadLine();
			string[] BlockExtensionString=lineread.Split(bob2);
			if(Convert.ToInt32(BlockExtensionString[0],16)!=1) UsingBlockExtension=false;
			else 
			{
				UsingBlockExtension=true;
				BlockExtensionCode=Convert.ToInt32(BlockExtensionString[1],16);
				BlockExtensionOffset=Convert.ToInt32(BlockExtensionString[2],16);
			}
			//fifth line - control block
			lineread=sr.ReadLine();
			string[] ControlExtensionString=lineread.Split(bob2);
			if(Convert.ToInt32(ControlExtensionString[0],16)!=1) UsingControlExtension=false;
			else 
			{
				UsingControlExtension=true;
				ControlExtensionCode=Convert.ToInt32(ControlExtensionString[1],16);
			}

			//sixth line - map width
			lineread=sr.ReadLine();
			string[] MapDetails=lineread.Split(bob2);
			MapWidth=Convert.ToInt32(MapDetails[0],16);
			this.DoingTwoByteBackground=(Convert.ToInt32(MapDetails[1],16)==1);

			//seventh line - ignore
			sr.ReadLine();

			//eighth onwards, block data
			bool MoreData=true;
			BlockDescriptor BDLine=new BlockDescriptor();
			//add not found element
			BDLine.Number=-1;
			BDLine.Sprite=-1;
			BDLine.Name="**unknown seek help**";
			DefinedBlocks.Add(BDLine);
			do
			{
				lineread=sr.ReadLine();
				if(lineread.StartsWith("-")) MoreData=false;
				else
				{
					BDLine=new BlockDescriptor();
					string[] BlockDataString=lineread.Split(bob2);
					BDLine.Number=Convert.ToInt32(BlockDataString[0],16);
					BDLine.Sprite=Convert.ToInt32(BlockDataString[1],16);
					BDLine.Name=BlockDataString[2];
					BDLine.Offsetxyz=Convert.ToInt32(BlockDataString[3],16);
					BDLine.MovementType=Convert.ToInt32(BlockDataString[4],16);
					BDLine.Extra=BlockDataString[5];
					BDLine.bmp=BlockDataString[6];
					BDLine.Type=1;		//block data
					DefinedBlocks.Add(BDLine);
				}
			} while(MoreData);

			//next line is also a comment
			sr.ReadLine();

			//read background data
			MoreData=true;
			do
			{
				lineread=sr.ReadLine();
				if(lineread.StartsWith("-")) MoreData=false;
				else
				{
					BDLine=new BlockDescriptor();
					string[] BlockDataString=lineread.Split(bob2);
					BDLine.Number=Convert.ToInt32(BlockDataString[0],16);
					BDLine.Sprite=Convert.ToInt32(BlockDataString[1],16);
					BDLine.Name=BlockDataString[2];
					BDLine.x=Convert.ToInt32(BlockDataString[3],16);
					BDLine.y=Convert.ToInt32(BlockDataString[4],16);
					BDLine.z=Convert.ToInt32(BlockDataString[5],16);
					BDLine.bgtype=Convert.ToInt32(BlockDataString[6],16);
					BDLine.bmp=BlockDataString[7];
					BDLine.exittype=BlockDataString[8];
					BDLine.Type=2;		//block data
					DefinedBlocks.Add(BDLine);
				}
			} while(MoreData);

			//dummy random block
			DefinedBlocks.Add(new BlockDescriptor(999,999,0,"Random Object",1));

			//next line start of specials
			sr.ReadLine();
			//read specials
			MoreData=true;
			BlockSpecial SPLine;
			do
			{
				lineread=sr.ReadLine();
				if(lineread.StartsWith("-")) MoreData=false;
				else
				{
					SPLine=new BlockSpecial();
					string[] BlockDataString=lineread.Split(bob2);
					SPLine.Name=BlockDataString[0];
					SPLine.Description=BlockDataString[1];
					SPLine.bmp=BlockDataString[2];
					SPLine.flag=Convert.ToInt32(BlockDataString[3],10);
					Specials.Add(SPLine);
				}
			} while(MoreData);

			sr.Close();
		}

		public int FindRoomIndex(int roomnumber)
		{
			for(int i=0;i<Rooms.Count;i++)
				if(((Room)Rooms[i]).ActualRoomID==roomnumber) return i;

			return -1;
		}

		public bool TransformData()
		{
			//convert location/object data to our internal format

			//location data
			//byte 0: room number
			//byte 1: bytes before next room
			//byte 2: room size (high 5 bits) and attributes (low 3 bits)
			//byte n: background byte until 0xFF
			//byte n: after 0xFF foreground bytes until next room starts
			//			foreground bytes:
			//			1 - high 5 bits are block type, low 3 are how many (0 index)
			//				each subsequent on (must be 1) is location
			//				location is high two bits y, next 3 z, low three x
			// alien8 (maybe pentagram) uses a special block 0x3f when it comes across this it is skipped
			//   but every block from then onwards adds 0x20 to the block - these two values are in the map file
			bool bRet=true;
			int CurrentItem=0;
			int RoomByteCount;
			bool DoingBackground=true;
			Room CurrentRoom=null;  //initialised below
			int BlockType;
			int BlockCount=0;
			Block myBlock=null;		//initialised below

			//loop until end of data
			Rooms.Clear();
			while(CurrentItem<LocationData.Count)
			{
				//create room
				DoingBackground=true;		//first part of room is background
				CurrentRoom=new Room();
				//byte 0
				CurrentRoom.ActualRoomID=(int)LocationData[CurrentItem];
				CurrentRoom.ID=(int)LocationData[CurrentItem];
				//byte 1
				CurrentItem++;
				RoomByteCount=(int)LocationData[CurrentItem]-1;
				CurrentRoom.ActualOffset=(int)LocationData[CurrentItem];
				//byte 2
				CurrentItem++;
				CurrentRoom.ActualRoomDetails=(int)LocationData[CurrentItem];
				CurrentRoom.LinkRoomEast=CurrentRoom.LinkRoomNorth=CurrentRoom.LinkRoomSouth=CurrentRoom.LinkRoomWest=-1;

				CurrentRoom.Size=(int)LocationData[CurrentItem]>>3;
				//bit of a hack here
				//alien8 - bits 3,4,5 are the colour to change to when cryonauts are freed, 7&8 is the room size
				//other games - bits 3,4 is the size
				
				//must be using bits 7/8
				if(CurrentRoom.Size>2)
				{
					CurrentRoom.Size=(int)LocationData[CurrentItem]>>6;
				}
				CurrentRoom.Attribute=(int)LocationData[CurrentItem]&0x7;
				DebugOut("Room: " + CurrentRoom.ID + ", Byte Count: " + (int)(RoomByteCount+1) + ", Room Details (" + CurrentRoom.ActualRoomDetails + ") Size: " + CurrentRoom.Size + ", Attribute: " + CurrentRoom.Attribute);

				//data for room
				bool GotBlock=false;
				bool AddingBlockExtension=false;	//for extra blocks
				int ControlExtensionValue=0;
				for(int i=CurrentItem+1;i<CurrentItem+RoomByteCount;i++)
				{
					//found the foreground/background seperator
					//skip 0xff byte - only if still doing background as FF is a valid block
					if((int)LocationData[i]==0xFF && DoingBackground)
					{
						DoingBackground=false;
					}
					else
					{
						if(!DoingBackground)
						{
							//end of background
							//doing foreground
							//may not have any foreground

							//if block extension is used (alien8) then this occurs after control extension
							//and block extension is reset to false, i.e. block extensions do not use control (location offset - usually Z) extension
							//block extension - for adding blocks after 1f
							//control extension - for adding blocks higher than Z=3
							if(!GotBlock)
							{
								DebugOut("Found some kind of block");
								GotBlock=true;
								myBlock=new Block();
								myBlock.ActualByte=(int)LocationData[i];
								BlockType=(int)LocationData[i]>>3;
								BlockCount=((int)LocationData[i]&0x7)+1;
								//check if adding extension
								if(AddingBlockExtension) 
									myBlock.Type=BlockType+this.BlockExtensionOffset;
								else
									myBlock.Type=BlockType;

								//check for control block after block extension
								//as control blocks not allowed after block extension
								if(UsingControlExtension && BlockType==this.ControlExtensionCode && !AddingBlockExtension)
								{
									//skip this block zero
									i++;
									ControlExtensionValue=(int)LocationData[i];
									GotBlock=false;
									DebugOut("FG: Control extension found.  Adding " + ControlExtensionValue +" to all blocks to follow.  Offset for Z is: " + ControlExtensionValue);
								}

								//check for block extension
								if(this.UsingBlockExtension && BlockType==this.BlockExtensionCode)
								{
									AddingBlockExtension=true;
									GotBlock=false;  //reset back so the next block has it
									DebugOut("FG: Block extension found.  Adding " + this.BlockExtensionCode+" to all blocks to follow");
									//skip next block which is always 0 - code must always read in pairs assuming its a control then a value
									i++;
								}
								else
									DebugOut("FG: " + myBlock.ActualByte + ", Type is " + BlockType + ", Item Count " + BlockCount);
							}
							else
							{
								BlockLocation myBlockLocation=new BlockLocation();
								myBlockLocation.ActualByte=(int)LocationData[i];
								//once the control block is used the offset is non-zero
								//and will always be non-zero until a block offset is used
								myBlockLocation.x=myBlockLocation.ActualByte&0x7;
								myBlockLocation.y=(myBlockLocation.ActualByte&0x38)>>3;
								if(UsingControlExtension && !AddingBlockExtension)
									myBlockLocation.z=(myBlockLocation.ActualByte>>6)+(ControlExtensionValue/12);
								else
									myBlockLocation.z=myBlockLocation.ActualByte>>6;

								myBlock.BlockLocations.Add(myBlockLocation);
								BlockCount--;
								DebugOut("   x,y,z,(refer to output for offsets): " + myBlockLocation.x+","+myBlockLocation.y+","+myBlockLocation.z);
								if(BlockCount<1)
								{
									CurrentRoom.ForegroundItems.Add(myBlock);
									GotBlock=false;
								}
							}
						}
						else
						{
							//doing background
							//each byte is a block until FF
							//if using two byte descriptors for background then instead of using a grid system
							// e.g. +-1 in east/west and +-16 in north/south
							// byte two is the room to jump to for this block
							DebugOut("BG: " + LocationData[i]);
							CurrentRoom.BackgroundItems.Add(LocationData[i]);
							BlockDescriptor bdTemp=this.FindBlockFromNumber(2,(int)LocationData[i]);
							if(this.DoingTwoByteBackground)
							{
								//increase count and get room link for this object
								i++;
								int RoomLink=(int)LocationData[i];
								DebugOut("BD: Extra byte link room is "+RoomLink);
								switch(bdTemp.exittype)
								{
									case "N":
										CurrentRoom.LinkRoomNorth=RoomLink;
										DebugOut("BG: found a north room link");
										break;
									case "E":
										CurrentRoom.LinkRoomEast=RoomLink;
										DebugOut("BG: found a east room link");
										break;
									case "S":
										CurrentRoom.LinkRoomSouth=RoomLink;
										DebugOut("BG: found a south room link");
										break;
									case "W":
										CurrentRoom.LinkRoomWest=RoomLink;
										DebugOut("BG: found a west room link");
										break;
								}
							}
							else
							{
								switch(bdTemp.exittype)
								{
									case "N":
										DebugOut("BG: found a north room link");
										CurrentRoom.LinkRoomNorth=CurrentRoom.ID+this.MapWidth;
										break;
									case "E":
										DebugOut("BG: found a east room link");
										CurrentRoom.LinkRoomEast=CurrentRoom.ID+1;
										break;
									case "S":
										DebugOut("BG: found a south room link");
										CurrentRoom.LinkRoomSouth=CurrentRoom.ID-this.MapWidth;
										break;
									case "W":
										DebugOut("BG: found a west room link");
										CurrentRoom.LinkRoomWest=CurrentRoom.ID-1;
										break;
								}

							}
						}					
					}
				}
				Rooms.Add(CurrentRoom);
				CurrentItem+=CurrentRoom.ActualOffset-1;
			}
			//object data
			CurrentItem=0;
			int x,y,z,room;
			DebugOut("");
			DebugOut("-------------------------------------------------");
			DebugOut("Doing object entries.  These are randomly selected and placed at set locations depending on the game");
			DebugOut("");
			for(CurrentItem=0;CurrentItem<ObjectData.Count;CurrentItem+=9)
			{
				x=(int)ObjectData[CurrentItem+1];
				y=(int)ObjectData[CurrentItem+2];
				z=(int)ObjectData[CurrentItem+3];
				room=(int)ObjectData[CurrentItem+4];
				Block tBlock=new Block();
				tBlock.Type=999;
				tBlock.BlockLocations.Add(new BlockLocation(999,x,y,z));
				try
				{
					((Room)Rooms[this.FindRoomIndex(room)]).RandomItems.Add(tBlock);
					DebugOut(" Room: " + room + ", location x,y,z : " + x + "," + y + "," + z);
				}
				catch
				{
					DebugOut(" Room ERROR: does not exist: " + room + ", location x,y,z : " + x + "," + y + "," + z);
					bRet=false;
				}
			}

			//specials
			DebugOut("");
			DebugOut("-------------------------------------------------");
			DebugOut("Doing Specials.  These are the specials and other game graphics");
			DebugOut("Flags: 0 is non-object, 8 special (see above), 16 player, 1,2,3,4 as background types");
			DebugOut("");
			foreach(BlockSpecial CurrentSpecial in Specials)
			{
				DebugOut(CurrentSpecial.Name + " ("+CurrentSpecial.Description+").  Flags: "+CurrentSpecial.flag);
			}

			if(this.debug!=null)
			{
				debug.Flush();
				debug.Close();
				debug=null;
			}
			return bRet;
		}

		public void DebugOut(string display)
		{
			if(debug==null)
				debug = new StreamWriter("outputs\\"+this.Prefixname+"_debuglog.txt");
			debug.WriteLine(display);
		}

		public void WriteToFile()
		{
			StreamWriter sw = new StreamWriter("outputs\\"+this.Prefixname+"_rawstructure.txt");
			int BlockCount=0;
			int BGCount=0;
			foreach(Room CurrentRoom in Rooms)
			{
				BlockCount+=CurrentRoom.ForegroundItems.Count;
				BGCount+=CurrentRoom.BackgroundItems.Count;
			}
			sw.WriteLine("There are {0} rooms, using {1} blocks and {2} background items.",Rooms.Count,BlockCount,BGCount);
			sw.WriteLine();
			foreach(Room CurrentRoom in this.Rooms)
			{
				sw.WriteLine("Room: " + CurrentRoom.ID + ", Byte Count: " + CurrentRoom.ActualOffset + ", Room Details (" + CurrentRoom.ActualRoomDetails + ") Size: " + CurrentRoom.Size + ", Attribute: " + CurrentRoom.Attribute);
				if(CurrentRoom.LinkRoomNorth!=-1) sw.WriteLine("Room Exit To North: "+CurrentRoom.LinkRoomNorth);
				if(CurrentRoom.LinkRoomEast!=-1) sw.WriteLine("Room Exit To East: "+CurrentRoom.LinkRoomEast);
				if(CurrentRoom.LinkRoomSouth!=-1) sw.WriteLine("Room Exit To South: "+CurrentRoom.LinkRoomSouth);
				if(CurrentRoom.LinkRoomWest!=-1) sw.WriteLine("Room Exit To West: "+CurrentRoom.LinkRoomWest);
				foreach(int Item in CurrentRoom.BackgroundItems)
				{
					BlockDescriptor bdTemp=this.FindBlockFromNumber(2,Item);
					sw.WriteLine("BG: " + Item + " ("+ bdTemp.Name + ")");
				}
				foreach(Block myBlock in CurrentRoom.ForegroundItems)
				{
					BlockDescriptor bdTemp=this.FindBlockFromNumber(1,myBlock.Type);
					sw.WriteLine("FG: " + myBlock.ActualByte + ", Type is " + myBlock.Type+ " (" + this.FindBlockFromNumber(1,myBlock.Type).Name+ ")"+ ", Item Count " + myBlock.BlockLocations.Count);
					foreach(BlockLocation myBlockLocation in myBlock.BlockLocations)
					{
						sw.WriteLine("   x,y,z,block type XYZ offset: " + myBlockLocation.x+","+myBlockLocation.y+","+myBlockLocation.z+","+bdTemp.Offsetxyz);
					}
				}
				sw.WriteLine("--------------------------------------------------");
				sw.WriteLine("objects");
				sw.WriteLine("");
				sw.WriteLine();
			}
			int room,x,y,z;
			for(int CurrentItem=0;CurrentItem<ObjectData.Count;CurrentItem+=9)
			{ 
				x=(int)ObjectData[CurrentItem+1];
				y=(int)ObjectData[CurrentItem+2];
				z=(int)ObjectData[CurrentItem+3];
				room=(int)ObjectData[CurrentItem+4];
				sw.WriteLine(" Room: " + room + ", location x,y,z : " + x + "," + y + "," + z);
			}

			sw.WriteLine("--------------------------------------------------");
			sw.WriteLine("specials");
			sw.WriteLine("");
			sw.WriteLine();
			foreach(BlockSpecial CurrentSpecial in Specials)
			{
				sw.WriteLine(CurrentSpecial.Name + " ("+CurrentSpecial.Description+").  Flags: "+CurrentSpecial.flag);
			}

			sw.Flush();
			sw.Close();
		}
		public string XMLOutput(string nicename,int[] startrooms)
		{
			StreamWriter sw;
			try 
			{
				sw=new StreamWriter("outputs\\"+this.Prefixname+"_xml.xml");
			}
			catch 
			{
				return "Failed to create output file outputs\\"+this.Prefixname+"_xml.xml";
			}
			try 
			{
				//header information
				sw.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				sw.WriteLine("<?xml-stylesheet type=\"text/xsl\" href=\"filmation.xslt\"?>");
				sw.WriteLine("<filmation xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"filmation.xsd\">");
														sw.WriteLine("\t<name>{0}</name>",nicename);
				sw.WriteLine("\t<hint>although pentagram could have any object making a jump, it isn't so it is assumed each wall has one door that corresponds exactly to one link room</hint>");
				sw.WriteLine("\t<hint>template section denotes the blue-print for an actual item</hint>");
				//rooms
				sw.WriteLine("\t<rooms>");
				sw.WriteLine("\t\t<hint>a room link of -1 means no exit in that direction</hint>");
				sw.WriteLine("\t\t<hint>In Knight Lore/Alien 8 rooms are 16x16 grids with 0 index, so navigation calculation is easy</hint>");
				sw.WriteLine("\t\t<hint>Pentagram there is no room/grid link so it is embedded with the data</hint>");
				sw.WriteLine("\t\t<hint>It does not matter here because the room link is stored as well so that can be used</hint>");
				sw.WriteLine("\t\t<hint>x and y offsets are half-blocks, i.e. 8 pixels in this game</hint>");
				sw.WriteLine("\t\t<hint>for all the games it is always either 0 or 1</hint>");
				sw.WriteLine("\t\t<hint>roomblocks use cell locations, except zpixeloffset which is pixels</hint>");
				sw.WriteLine("\t\t<hint>the normal height of blocks is 12 pixels and the offset is multiplied by 4. So offsetz of 12 is 4 blocks</hint>");
				sw.WriteLine("\t\t<hint>this then allows positions 4 to 8 to be used (in knight lore)</hint>");
				sw.WriteLine("\t\t<hint>startup rooms are those rooms where the player starts at random. all original games have 4 starting points</hint>");
				
				sw.WriteLine("\t\t<startuprooms>");
				foreach(int a in startrooms) sw.WriteLine("\t\t\t<startuproomid>{0}</startuproomid>",a);
				sw.WriteLine("\t\t</startuprooms>");

				ArrayList RoomSpecials=new ArrayList();
				if(ObjectData.Count>0)
				{
					sw.WriteLine("\t\t<specials>");
					sw.WriteLine("\t\t\t<hint>Each location starts from an offset, e.g. 72,72,128 are 0,0,0 (x/y/z) for knight lore</hint>");
					sw.WriteLine("\t\t\t<hint>Alien 8 uses 72,72,64 as the x/y/z 0 locations</hint>");
					sw.WriteLine("\t\t\t<hint>Pentagram uses 72,72,128 as the x/y/z 0 locations</hint>");
					int room,x,y,z;
					for(int CurrentItem=0;CurrentItem<ObjectData.Count;CurrentItem+=9)
					{ 
						room=(int)ObjectData[CurrentItem+4];
						RoomSpecials.Add((int)room);
						x=(int)ObjectData[CurrentItem+1];
						y=(int)ObjectData[CurrentItem+2];
						z=(int)ObjectData[CurrentItem+3];
						sw.WriteLine("\t\t\t<special>");
						sw.WriteLine("\t\t\t\t<roomlocation>{0}</roomlocation>",room);
						sw.WriteLine("\t\t\t\t<x>{0}</x>",x);
						sw.WriteLine("\t\t\t\t<y>{0}</y>",y);
						sw.WriteLine("\t\t\t\t<z>{0}</z>",z);
						sw.WriteLine("\t\t\t</special>");
					}
					sw.WriteLine("\t\t</specials>");
				}
				foreach(Room CurrentRoom in Rooms)
				{
					//room core details
					sw.WriteLine("\t\t<room>");
					sw.WriteLine("\t\t\t<roomid>{0}</roomid>",CurrentRoom.ID);
					sw.WriteLine("\t\t\t<size>{0}</size>",CurrentRoom.Size);
					//links
					sw.WriteLine("\t\t\t<links>");
						sw.WriteLine("\t\t\t\t<linknorth>{0}</linknorth>",CurrentRoom.LinkRoomNorth);
						sw.WriteLine("\t\t\t\t<linkeast>{0}</linkeast>",CurrentRoom.LinkRoomEast);
						sw.WriteLine("\t\t\t\t<linksouth>{0}</linksouth>",CurrentRoom.LinkRoomSouth);
						sw.WriteLine("\t\t\t\t<linkwest>{0}</linkwest>",CurrentRoom.LinkRoomWest);
					sw.WriteLine("\t\t\t</links>");
					string spHere="N";
					if(RoomSpecials.Contains(CurrentRoom.ID)) spHere="Y";
					sw.WriteLine("\t\t\t<specialhere>{0}</specialhere>",spHere);
					//background items
					sw.WriteLine("\t\t\t<backgrounds>");
					foreach(int Item in CurrentRoom.BackgroundItems)
						sw.WriteLine("\t\t\t\t<backgroundobject>{0}</backgroundobject>",Item);
					sw.WriteLine("\t\t\t</backgrounds>");
					//room objects
					sw.WriteLine("\t\t\t<objects>");
					sw.WriteLine("\t\t\t\t<roomblocks>");
					foreach(Block myBlock in CurrentRoom.ForegroundItems)
					{
						BlockDescriptor bdTemp=this.FindBlockFromNumber(1,myBlock.Type);
						foreach(BlockLocation myBlockLocation in myBlock.BlockLocations)
						{
							sw.WriteLine("\t\t\t\t\t<roomblock>");
							sw.WriteLine("\t\t\t\t\t\t<objecttypeid>{0}</objecttypeid>",myBlock.Type);
							sw.WriteLine("\t\t\t\t\t\t<x>{0}</x>",myBlockLocation.x);
							sw.WriteLine("\t\t\t\t\t\t<y>{0}</y>",myBlockLocation.y);
							sw.WriteLine("\t\t\t\t\t\t<z>{0}</z>",myBlockLocation.z);
							if((bdTemp.Offsetxyz&0x1)!=0)
								sw.WriteLine("\t\t\t\t\t\t<xoffset>1</xoffset>");
							else
								sw.WriteLine("\t\t\t\t\t\t<xoffset>0</xoffset>");
							if((bdTemp.Offsetxyz&0x2)!=0)
								sw.WriteLine("\t\t\t\t\t\t<yoffset>1</yoffset>");
							else
								sw.WriteLine("\t\t\t\t\t\t<yoffset>0</yoffset>");
							sw.WriteLine("\t\t\t\t\t\t<zpixeloffset>{0}</zpixeloffset>",(bdTemp.Offsetxyz>>2).ToString());
							sw.WriteLine("\t\t\t\t\t</roomblock>");
						}
					}
					sw.WriteLine("\t\t\t\t</roomblocks>");
					sw.WriteLine("\t\t\t</objects>");
					sw.WriteLine("\t\t</room>");
				}
				sw.WriteLine("\t</rooms>");

				//template data - this is the actual lookup values

				//template
				sw.WriteLine("\t<template>");

				//room sizes
				sw.WriteLine("\t\t<roomsizes>");
				sw.WriteLine("\t\t\t<hint>Sizes are in cell blocks</hint>");
				int i=0;
				foreach(RoomSize CurrentRoomSize in RoomSizes)
				{
					sw.WriteLine("\t\t\t<roomsize>");
					sw.WriteLine("\t\t\t\t<roomtype>{0}</roomtype>",i++);
					sw.WriteLine("\t\t\t\t<x>{0}</x>",CurrentRoomSize.x);
					sw.WriteLine("\t\t\t\t<y>{0}</y>",CurrentRoomSize.y);
					sw.WriteLine("\t\t\t\t<z>{0}</z>",CurrentRoomSize.z);
					sw.WriteLine("\t\t\t</roomsize>");
				}
				sw.WriteLine("\t\t</roomsizes>");

				//backgrounds
				sw.WriteLine("\t\t<backgroundtypes>");
				sw.WriteLine("\t\t\t<hint>Z type is object moving z only, FREE is free-roaming, DOOR/WALL as named</hint>");
				sw.WriteLine("\t\t\t<hint>Pentagram/A8 only has WALL/DOORs here</hint>");
				sw.WriteLine("\t\t\t<hint>In Knight Lore best to treat Z/FREE as room objects not background items</hint>");
				sw.WriteLine("\t\t\t<hint>Doors/walls do not have positions so treat x/y/z (which should be 0) as your own to place</hint>");
				sw.WriteLine("\t\t\t<hint>Exit type is only valid with DOORs</hint>");
				foreach(BlockDescriptor BD in this.DefinedBlocks)
				{
					if(BD.Type==2)
					{
						string bgtype="ERRORINTYPE";
						sw.WriteLine("\t\t\t<backgrounditem>");
						switch(BD.bgtype)
						{
							case 1:
								bgtype="DOOR";
								break;
							case 2:
								bgtype="Z";
								break;
							case 3:
								bgtype="FREE";
								break;
							case 4:
								bgtype="WALL";
								break;
						}
						sw.WriteLine("\t\t\t\t<bgtype>{0}</bgtype>",bgtype);
						sw.WriteLine("\t\t\t\t<causesexit>{0}</causesexit>",(BD.exittype==""?"NONE":BD.exittype));
						sw.WriteLine("\t\t\t\t<id>{0}</id>",BD.Number);
						sw.WriteLine("\t\t\t\t<bitmap>{0}</bitmap>",BD.bmp);
						sw.WriteLine("\t\t\t\t<name>{0}</name>",BD.Name);
						sw.WriteLine("\t\t\t</backgrounditem>");
					}
				}
				sw.WriteLine("\t\t</backgroundtypes>");
				
				//room blocks
				sw.WriteLine("\t\t<blocks>");
				sw.WriteLine("\t\t\t<hint>Z movement type can also mean fixed - have to look at description to determine this</hint>");
				foreach(BlockDescriptor BD in this.DefinedBlocks)
				{
					if(BD.Type==1)
					{
						sw.WriteLine("\t\t\t<blocktype>");
						sw.WriteLine("\t\t\t\t<id>{0}</id>",BD.Number);
						sw.WriteLine("\t\t\t\t<bitmap>{0}</bitmap>",BD.bmp);
						sw.WriteLine("\t\t\t\t<name>{0}</name>",BD.Name);
						sw.WriteLine("\t\t\t\t<movementtype>{0}</movementtype>",(BD.MovementType==1?"Z":"FREE"));
						sw.WriteLine("\t\t\t\t<extra>{0}</extra>",BD.Extra);
						sw.WriteLine("\t\t\t</blocktype>");
					}
				}
				sw.WriteLine("\t\t</blocks>");
				
				sw.WriteLine("\t</template>");


				//finish
				sw.WriteLine("</filmation>");
				sw.Flush();
				sw.Close();
			}
			catch
			{
				return "Failed writing the main XML data or closing the file";
			}
			return "";	//success
		}

		public int GenerateLocationData()
		{
			//generate data to return
			//should always match exactly the existing site if no changes :)

			//loop all rooms
			//write room header bytes
			//write background data from background items
			//write 0xFF seperator if foreground items
			//write all blocks

			//blocks written as follows:
			//create block byte to combine block type and number of locations
			//write locations
			//repeat
			//don't know size of each room until end so write two strings then join

			StringBuilder sRoom;
			int RoomOffsets=0;
			int BlockItem=0;
			StringBuilder sRooms=new StringBuilder();
			foreach(Room myRoom in Rooms)
			{
				int RoomOffset=0;
				//header
				sRoom=new StringBuilder();
				sRoom.Append(ToHexString(myRoom.ActualRoomDetails)+",");				//2 - size
				RoomOffset++;
				//backgrounds
				foreach(int BackgroundItem in myRoom.BackgroundItems)
				{
					sRoom.Append(ToHexString(BackgroundItem)+",");						//3+ background
					RoomOffset++;
				}

				//seperater
				if(myRoom.ForegroundItems.Count>0)
				{
					sRoom.Append("0x0FF,");
					RoomOffset++;
				}

				//data should be optimised already as only one block is used per (upto) 8 locations

				//1. items either not using a block offset and not using a control block
				//		or using a control offset but the z is <4
				//		for kl this will include all objects in this loop as neither are used
					//room block items
					BlockItem=0;
					int bcount=0;
					foreach(Block myBlock in myRoom.ForegroundItems)
					{
						//block type
						BlockItem=myBlock.Type<<3;
						bcount=0;

						//block extensions last
						if(this.UsingBlockExtension && myBlock.Type>=this.BlockExtensionOffset)
							//break;
							continue;

						//get block count - any above 4 may not be counted so cannot just use block count
						foreach(BlockLocation myLocation in myBlock.BlockLocations)
						{
							int LocationByte=0;
							LocationByte=myLocation.z<<6;
							if(!this.UsingControlExtension || (this.UsingControlExtension && myLocation.z<4))
								bcount++;
						}

						if(bcount>0)
						{
							string Items=ToHexString((bcount-1) | BlockItem)+",";
							int Offset=0;
							bool gotone=false;
							
							//locations
							foreach(BlockLocation myLocation in myBlock.BlockLocations)
							{
								int LocationByte=0;
								LocationByte=myLocation.z<<6;
								LocationByte |=myLocation.y<<3;
								LocationByte |=myLocation.x;
								//if not using control extension or if we are and the z is in bottom half, then add it
								if(!this.UsingControlExtension || (this.UsingControlExtension && myLocation.z<4))
								{
									if(Offset==0) Offset=1;
									Items+=ToHexString(LocationByte)+",";
									Offset++;
									gotone=true;
								}
							}
							if(gotone)
							{
								sRoom.Append(Items);
								RoomOffset+=Offset;
							}
						}
					}

				//2. control block items for z values of position 4,5,6,7
					BlockItem=0;
					bool bResetZ=false;

					if(this.UsingControlExtension)
					{
						//first ensure there are items that require a control block
						bcount=0;
						foreach(Block myBlock in myRoom.ForegroundItems)
						{
							foreach(BlockLocation myLocation in myBlock.BlockLocations)
							{
								if(myLocation.z>3) 
									bcount++;
							}
						}

						//only check if there are any
						if(bcount>0)
						{
							int Offset=2;
							bResetZ=true;
							//write control block bytes
							//	first is the type with number of items 0 - a8 it is 0
							//	second is the xyz offset - a8 always has 30 so hard coding it :)
							sRoom.Append(ToHexString(this.ControlExtensionCode)+",0x030,");

							foreach(Block myBlock in myRoom.ForegroundItems)
							{
								//block type
								BlockItem=myBlock.Type<<3;

								bcount=0;
								foreach(BlockLocation myLocation in myBlock.BlockLocations)
								{
									if(myLocation.z>3) bcount++;
								}
								
								//block extensions last
								if(this.UsingBlockExtension && myBlock.Type>=this.BlockExtensionOffset)
									//break;
									continue;

								string Items=ToHexString((bcount-1) | BlockItem)+",";
								bool definitegotone=false;
										
								//locations
								foreach(BlockLocation myLocation in myBlock.BlockLocations)
								{
									int LocationByte=0;
									int z=myLocation.z;	//get value
									//remove z offset, (x/y) are never offset

									//this should really use the offset but I know its always this :)
									if(z>3) z-=4;

									LocationByte=z<<6;
									LocationByte |=myLocation.y<<3;
									LocationByte |=myLocation.x;
									//if not using control extension or if we are and the z is in bottom half, then add it
									if(this.UsingControlExtension && myLocation.z>3)
									{
										Items+=ToHexString(LocationByte)+",";
										Offset++;
										definitegotone=true;
									}
								}
								if(definitegotone)
								{
									Offset++;		//for the initial block item
									sRoom.Append(Items);
								}
							}
							RoomOffset+=Offset;
						}
					}

				//3. block offsets
				//   remember block offsets never use control offsets so can ignore any checks
				//	 but need to reset z offset if previously been set
				BlockItem=0;

				if(this.UsingBlockExtension)
				{
					bcount=0;
					foreach(Block myBlock in myRoom.ForegroundItems)
					{
						if(myBlock.Type>=this.BlockExtensionOffset)
						{
							bcount++;
						}
					}

					//only check if there are any
					if(bcount>0)
					{
						//
						int Offset=2;
						//first ensure there are items that require a block extension
						if(bResetZ)
						{
							//reset back to 0 z offset
							sRoom.Append(ToHexString(this.ControlExtensionCode)+",0x000,");
							Offset+=2;
						}


						//write control block bytes
						//	first is the type with number of items 0
						//	second is a zero byte
						sRoom.Append(ToHexString(this.BlockExtensionCode<<3)+",0x000,");

						foreach(Block myBlock in myRoom.ForegroundItems)
						{
							//block type
							BlockItem=myBlock.Type-this.BlockExtensionOffset;	//ofset
							BlockItem<<=3;				//actual byte
							//block extensions last
							if(myBlock.Type<this.BlockExtensionCode)
								continue;

							string Items=ToHexString(myBlock.BlockLocations.Count-1 | BlockItem)+",";
							bool definitegotone=false;
										
							//locations
							foreach(BlockLocation myLocation in myBlock.BlockLocations)
							{
								int LocationByte=0;
								LocationByte=myLocation.z<<6;		//will never be high z
								LocationByte |=myLocation.y<<3;
								LocationByte |=myLocation.x;
								Items+=ToHexString(LocationByte)+",";
								Offset++;
								definitegotone=true;
							}
							if(definitegotone)
							{
								Offset++;
								sRoom.Append(Items);
							}
						}
						RoomOffset+=Offset;
					}
				}

				//header bytes backwards
				sRoom.Insert(0,ToHexString(RoomOffset+1)+",");									//1 - offset  to next room
				sRoom.Insert(0,ToHexString(myRoom.ActualRoomID)+",");									//0	- id
				RoomOffset+=2;
				sRooms.Append(sRoom);
				RoomOffsets+=RoomOffset;
			}	

			if(sRooms.ToString().EndsWith(",")) 
				sRooms.Remove(sRooms.Length-1,1);

			this.CurrentLocationDataSize=RoomOffsets;
			//output entry to file
			this.WriteNewMap(sRooms.ToString());

			return RoomOffsets;
		}
		public string ToHexString(int num)
		{
			return "0x" + num.ToString("X").PadLeft(3,'0');
		}

		public void WriteNewMap(string roomsData)
		{
			if(this.AdditionalLocation=="") 
				return;

			StreamReader sr;
			string FileName="maps\\"+this.Prefixname+"_map_user.txt";
			char[] bob2=",".ToCharArray();
			ArrayList al=new ArrayList();
			string lineread;

			//populate arraylist
			sr=new StreamReader(FileName);
			while((lineread=sr.ReadLine()) !=null)
			{
				string[] LocationDataString2=lineread.Split(bob2);
				if(LocationDataString2[0]!="")
				{
					if(LocationDataString2[0]==AdditionalLocation)
						//writing this one
						al.Add(AdditionalLocation+","+roomsData);
					else
						//output it back
						al.Add(lineread);
				}
			}
			sr.Close();
			//re-write the data
			StreamWriter sw=new StreamWriter(FileName,false);
			foreach(string ss in al)
				sw.WriteLine(ss);

			sw.Close();

		}
	}

	public class Room
	{
		public int ActualRoomID;			//actual byte read
		public int ActualOffset;			//actual offset bytes read
		public int ActualRoomDetails;		//actual room details (size/attributes) read
		public int ID;						//room number - corresponds to grid
		public int Size;					//bytes offset to next room - including current room
		public int Attribute;				//spectrum ink/background colour
		public ArrayList BackgroundItems;	//walls, doors
		public ArrayList ForegroundItems;	//room objects
		public ArrayList RandomItems;		//items from object table
		public int LinkRoomNorth;
		public int LinkRoomEast;
		public int LinkRoomWest;
		public int LinkRoomSouth;
		public Room()
		{
			BackgroundItems=new ArrayList();
			ForegroundItems=new ArrayList();
			RandomItems=new ArrayList();
		}
	};

	public struct RoomSize
	{
		public string description;
		public int x;
		public int y;
		public int z;
	};

	public class Block
	{
		public int ActualByte;				//actual byte read
		public int Type;					//type of block
		public ArrayList BlockLocations;	//repeating locations of this block in this room
		public Block()
		{
			BlockLocations=new ArrayList();
		}

	};

	public class BlockLocation
	{
		public int ActualByte;				//actual byte read
		public int x;
		public int y;
		public int z;
		public BlockLocation() {x=y=z=ActualByte=0;}
		public BlockLocation(int AB, int X,int Y, int Z)
		{
			ActualByte=AB; x=X;y=Y;z=Z;
		}
	};

	public struct BlockDescriptor
	{
		public int Type;		//1 FG, 2 BG
		public int Number;
		public int Sprite;		//which sprite it is - refer to graphics file using AB as down and across
		public string Name;
		public string Extra;
		public string bmp;
		public int Offsetxyz;	//for block data the byte offset
		public int MovementType;	//1 z only, 2 free
		//these three for background data
		public int x;			
		public int y;
		public int z;
		//use this to determine if using grid or pixel positioning and creating grid or free objects
		public int bgtype;
		public string exittype;

		public BlockDescriptor(int t, int n, int s, string na, int pm)
		{
			Type=t;
			Number=n;
			Sprite=s;
			Name=na;
			MovementType=pm;
			exittype="";
			this.Extra="";
			this.Offsetxyz=0;
			this.z=this.x=this.y=this.bgtype=0;
			bmp="";
		}
	};

	public struct BlockSpecial
	{
		public string Name;
		public string Description;
		public string bmp;
		public int flag;
	};
}

