using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace Retrospec.IsoConverter
{
	/// <summary>
	/// Summary description for SelectMap.
	/// </summary>
	public class SelectMap : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button AddMap;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button EditMap;
		private System.Windows.Forms.Button CancelMap;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string DefaultText;
		private string FilePrefix;
		public SelectMap()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.AddMap = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.EditMap = new System.Windows.Forms.Button();
			this.CancelMap = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(32, 31);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Name";
			// 
			// AddMap
			// 
			this.AddMap.Location = new System.Drawing.Point(192, 24);
			this.AddMap.Name = "AddMap";
			this.AddMap.Size = new System.Drawing.Size(96, 24);
			this.AddMap.TabIndex = 4;
			this.AddMap.Text = "Add New Map";
			this.AddMap.Click += new System.EventHandler(this.AddMap_Click);
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(32, 96);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(152, 108);
			this.listBox1.TabIndex = 5;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(84, 27);
			this.textBox1.Name = "textBox1";
			this.textBox1.TabIndex = 6;
			this.textBox1.Text = "";
			// 
			// EditMap
			// 
			this.EditMap.Location = new System.Drawing.Point(192, 176);
			this.EditMap.Name = "EditMap";
			this.EditMap.Size = new System.Drawing.Size(96, 24);
			this.EditMap.TabIndex = 7;
			this.EditMap.Text = "Edit Map";
			this.EditMap.Click += new System.EventHandler(this.EditMap_Click);
			// 
			// CancelMap
			// 
			this.CancelMap.Location = new System.Drawing.Point(192, 240);
			this.CancelMap.Name = "CancelMap";
			this.CancelMap.Size = new System.Drawing.Size(96, 24);
			this.CancelMap.TabIndex = 8;
			this.CancelMap.Text = "Close";
			this.CancelMap.Click += new System.EventHandler(this.CancelMap_Click);
			// 
			// SelectMap
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.CancelMap);
			this.Controls.Add(this.EditMap);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.AddMap);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "SelectMap";
			this.Text = "SelectMap";
			this.Load += new System.EventHandler(this.SelectMap_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void CancelMap_Click(object sender, System.EventArgs e)
		{
			this.Tag="";
			this.Hide();
		}

		private void EditMap_Click(object sender, System.EventArgs e)
		{
			this.Tag=this.listBox1.Text;
			this.Hide();
		}

		private void AddMap_Click(object sender, System.EventArgs e)
		{
			if(this.textBox1.Text!="" && this.listBox1.FindStringExact(this.textBox1.Text)==-1)
			{
				StreamWriter sr;
				try
				{
					sr=new StreamWriter("maps\\"+FilePrefix+"_map_user.txt",true);
				}
				catch
				{
					MessageBox.Show(this,"maps\\"+FilePrefix+"_map_user.txt" + "could not be opened for appending data");
					return;
				}
				sr.WriteLine(this.textBox1.Text+","+DefaultText);
				sr.Close();
				this.Tag=this.textBox1.Text;
				this.Hide();
				MessageBox.Show(this,"Map added with the values from the original game");
			}
			else
			{
				MessageBox.Show(this,"Cannot accept blank names or those that already exist");
			}
		}

		public bool PopulateData(string fileprefix)
		{
			StreamReader sr;

			FilePrefix=fileprefix;
			try
			{
				sr=new StreamReader("maps\\"+fileprefix+"_map_user.txt");
			}
			catch
			{
				MessageBox.Show(this,"maps\\"+fileprefix+"_map_user.txt" + " was not found, cannot continue as the default map is required as a minimum.");
				this.textBox1.Enabled=false;
				return false;
			}
			char[] bob2=",".ToCharArray();
			string lineread;

			//first line - locations
			while((lineread=sr.ReadLine()) !=null)
			{
				string[] LocationDataString=lineread.Split(bob2);
				if(LocationDataString[0]!="")
				{
					if(LocationDataString[0]=="default")
					{
						foreach(string a in LocationDataString)
						{
							if(a!="default") DefaultText+=(a+",");
						}
						if(DefaultText.EndsWith(",")) DefaultText=DefaultText.TrimEnd(bob2);
					}
					else
						this.listBox1.Items.Add(LocationDataString[0]);
				}
			}
			sr.Close();
			return true;
		}

		private void SelectMap_Load(object sender, System.EventArgs e)
		{
		
		}

	}
}
