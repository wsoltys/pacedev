using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using GlacialComponents;

namespace Retrospec.IsoConverter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ContextMenu MapLoader;
		private System.Windows.Forms.MenuItem MenuKnightlore;
		private System.Windows.Forms.MenuItem MenuAlien8;
		private System.Windows.Forms.MenuItem MenuPentagram;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private IsoData myData;
		private string LastItem;
		private bool EditDirty;
		private bool RefreshRequired;
		private GlacialComponents.Controls.GLSubItem LastItemElement;
		private System.Windows.Forms.ImageList ImageListFG;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.ToolBar ToolbarMain;
		private System.Windows.Forms.ToolBarButton ButtonLoad;
		private System.Windows.Forms.ToolBarButton ButtonHelp;
		private System.Windows.Forms.ToolBarButton toolBarButton1;
		private System.Windows.Forms.ToolBarButton ButtonExit;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.RadioButton RadioIsoCis;
		private System.Windows.Forms.RadioButton RadioXML;
		private System.Windows.Forms.RadioButton RadioRaw;
		private System.Windows.Forms.RadioButton RadioDebug;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ListBox ListSpecials;
		private System.Windows.Forms.Label LabelOffset;
		private System.Windows.Forms.Label LabelFG;
		private System.Windows.Forms.Label LabelBG;
		private System.Windows.Forms.Label LabelAttr;
		private System.Windows.Forms.Label LabelType;
		private System.Windows.Forms.Label LabelID;
		private System.Windows.Forms.ListBox ListboxRooms;
		private System.Windows.Forms.Label LabelRooms;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.ToolBarButton RenderRoom;
		private System.Windows.Forms.ToolBarButton RenderMap;
		private System.Windows.Forms.Label label9;
		private GlacialComponents.Controls.GlacialList glList;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label13;
		private GlacialComponents.Controls.GlacialList glMap;
		private System.Windows.Forms.Label LabelRoomLinks;
		private GlacialComponents.Controls.GlacialList glSpecials;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ImageList ImageListSP;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ToolBarButton ButtonItems;
		private System.Windows.Forms.ToolBarButton ButtonEdit;
		private System.Windows.Forms.ContextMenu MapEditor;
		private System.Windows.Forms.MenuItem MenuEditKL;
		private System.Windows.Forms.MenuItem MenuEditA8;
		private System.Windows.Forms.Panel PanelEditMode;
		private System.Windows.Forms.Button ButtonCreateGame;
		private System.Windows.Forms.Button ButtonAddRow;
		private System.Windows.Forms.Button ButtonDeleteRow;
		private System.Windows.Forms.Label LabelSizings;
		private System.Windows.Forms.Button EditRow;
		private System.Windows.Forms.Button ButtonRefresh;
		private System.ComponentModel.IContainer components;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			SplashScreen ss=new SplashScreen(false);
			ss.TopLevel=true;
			ss.Show();
			Application.DoEvents();
			System.Threading.Thread.Sleep(3000);
			ss.Close();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			myData=new IsoData();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			GlacialComponents.Controls.GLColumn glColumn1 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn2 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn3 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn4 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn5 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn6 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn7 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn8 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn9 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn10 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn11 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn12 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn13 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn14 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn15 = new GlacialComponents.Controls.GLColumn();
			GlacialComponents.Controls.GLColumn glColumn16 = new GlacialComponents.Controls.GLColumn();
			this.MapLoader = new System.Windows.Forms.ContextMenu();
			this.MenuKnightlore = new System.Windows.Forms.MenuItem();
			this.MenuAlien8 = new System.Windows.Forms.MenuItem();
			this.MenuPentagram = new System.Windows.Forms.MenuItem();
			this.ImageListFG = new System.Windows.Forms.ImageList(this.components);
			this.panel1 = new System.Windows.Forms.Panel();
			this.label9 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.RadioIsoCis = new System.Windows.Forms.RadioButton();
			this.RadioXML = new System.Windows.Forms.RadioButton();
			this.RadioRaw = new System.Windows.Forms.RadioButton();
			this.RadioDebug = new System.Windows.Forms.RadioButton();
			this.ToolbarMain = new System.Windows.Forms.ToolBar();
			this.ButtonLoad = new System.Windows.Forms.ToolBarButton();
			this.ButtonEdit = new System.Windows.Forms.ToolBarButton();
			this.MapEditor = new System.Windows.Forms.ContextMenu();
			this.MenuEditKL = new System.Windows.Forms.MenuItem();
			this.MenuEditA8 = new System.Windows.Forms.MenuItem();
			this.ButtonItems = new System.Windows.Forms.ToolBarButton();
			this.RenderRoom = new System.Windows.Forms.ToolBarButton();
			this.RenderMap = new System.Windows.Forms.ToolBarButton();
			this.ButtonHelp = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.ButtonExit = new System.Windows.Forms.ToolBarButton();
			this.label8 = new System.Windows.Forms.Label();
			this.ListSpecials = new System.Windows.Forms.ListBox();
			this.LabelOffset = new System.Windows.Forms.Label();
			this.LabelFG = new System.Windows.Forms.Label();
			this.LabelBG = new System.Windows.Forms.Label();
			this.LabelAttr = new System.Windows.Forms.Label();
			this.LabelType = new System.Windows.Forms.Label();
			this.LabelID = new System.Windows.Forms.Label();
			this.ListboxRooms = new System.Windows.Forms.ListBox();
			this.LabelRooms = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.glList = new GlacialComponents.Controls.GlacialList();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.glMap = new GlacialComponents.Controls.GlacialList();
			this.LabelRoomLinks = new System.Windows.Forms.Label();
			this.glSpecials = new GlacialComponents.Controls.GlacialList();
			this.ImageListSP = new System.Windows.Forms.ImageList(this.components);
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.PanelEditMode = new System.Windows.Forms.Panel();
			this.ButtonRefresh = new System.Windows.Forms.Button();
			this.EditRow = new System.Windows.Forms.Button();
			this.ButtonCreateGame = new System.Windows.Forms.Button();
			this.ButtonAddRow = new System.Windows.Forms.Button();
			this.ButtonDeleteRow = new System.Windows.Forms.Button();
			this.LabelSizings = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.PanelEditMode.SuspendLayout();
			this.SuspendLayout();
			// 
			// MapLoader
			// 
			this.MapLoader.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuKnightlore,
																					  this.MenuAlien8,
																					  this.MenuPentagram});
			// 
			// MenuKnightlore
			// 
			this.MenuKnightlore.Index = 0;
			this.MenuKnightlore.Text = "Knight Lore";
			this.MenuKnightlore.Click += new System.EventHandler(this.MenuKnightlore_Click);
			// 
			// MenuAlien8
			// 
			this.MenuAlien8.Index = 1;
			this.MenuAlien8.Text = "Alien8";
			this.MenuAlien8.Click += new System.EventHandler(this.MenuAlien8_Click);
			// 
			// MenuPentagram
			// 
			this.MenuPentagram.Index = 2;
			this.MenuPentagram.Text = "Pentagram";
			this.MenuPentagram.Click += new System.EventHandler(this.MenuPentagram_Click);
			// 
			// ImageListFG
			// 
			this.ImageListFG.ImageSize = new System.Drawing.Size(64, 64);
			this.ImageListFG.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageListFG.ImageStream")));
			this.ImageListFG.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.label9);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.ToolbarMain);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1016, 54);
			this.panel1.TabIndex = 39;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.Location = new System.Drawing.Point(475, 17);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(173, 17);
			this.label9.TabIndex = 40;
			this.label9.Text = "All Values are in Decimal";
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.RadioIsoCis);
			this.panel2.Controls.Add(this.RadioXML);
			this.panel2.Controls.Add(this.RadioRaw);
			this.panel2.Controls.Add(this.RadioDebug);
			this.panel2.Location = new System.Drawing.Point(653, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(359, 50);
			this.panel2.TabIndex = 39;
			// 
			// RadioIsoCis
			// 
			this.RadioIsoCis.Location = new System.Drawing.Point(71, 5);
			this.RadioIsoCis.Name = "RadioIsoCis";
			this.RadioIsoCis.Size = new System.Drawing.Size(61, 19);
			this.RadioIsoCis.TabIndex = 4;
			this.RadioIsoCis.Text = "IsoCis";
			this.RadioIsoCis.Click += new System.EventHandler(this.RadioIsoCis_Click);
			// 
			// RadioXML
			// 
			this.RadioXML.Location = new System.Drawing.Point(72, 24);
			this.RadioXML.Name = "RadioXML";
			this.RadioXML.Size = new System.Drawing.Size(61, 18);
			this.RadioXML.TabIndex = 2;
			this.RadioXML.Text = "XML";
			this.RadioXML.Click += new System.EventHandler(this.RadioXML_Click);
			// 
			// RadioRaw
			// 
			this.RadioRaw.Location = new System.Drawing.Point(10, 24);
			this.RadioRaw.Name = "RadioRaw";
			this.RadioRaw.Size = new System.Drawing.Size(61, 17);
			this.RadioRaw.TabIndex = 1;
			this.RadioRaw.Text = "Basic";
			this.RadioRaw.Click += new System.EventHandler(this.RadioRaw_Click);
			// 
			// RadioDebug
			// 
			this.RadioDebug.Checked = true;
			this.RadioDebug.Location = new System.Drawing.Point(10, 5);
			this.RadioDebug.Name = "RadioDebug";
			this.RadioDebug.Size = new System.Drawing.Size(61, 19);
			this.RadioDebug.TabIndex = 0;
			this.RadioDebug.TabStop = true;
			this.RadioDebug.Text = "Debug";
			this.RadioDebug.Click += new System.EventHandler(this.RadioDebug_Click);
			// 
			// ToolbarMain
			// 
			this.ToolbarMain.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						   this.ButtonLoad,
																						   this.ButtonEdit,
																						   this.ButtonItems,
																						   this.RenderRoom,
																						   this.RenderMap,
																						   this.ButtonHelp,
																						   this.toolBarButton1,
																						   this.ButtonExit});
			this.ToolbarMain.Dock = System.Windows.Forms.DockStyle.None;
			this.ToolbarMain.DropDownArrows = true;
			this.ToolbarMain.Location = new System.Drawing.Point(1, -1);
			this.ToolbarMain.Name = "ToolbarMain";
			this.ToolbarMain.ShowToolTips = true;
			this.ToolbarMain.Size = new System.Drawing.Size(510, 42);
			this.ToolbarMain.TabIndex = 2;
			this.ToolbarMain.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.ToolbarMain_ButtonClick);
			// 
			// ButtonLoad
			// 
			this.ButtonLoad.DropDownMenu = this.MapLoader;
			this.ButtonLoad.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.ButtonLoad.Tag = "L";
			this.ButtonLoad.Text = "Load Map";
			this.ButtonLoad.ToolTipText = "Loads the map file";
			// 
			// ButtonEdit
			// 
			this.ButtonEdit.DropDownMenu = this.MapEditor;
			this.ButtonEdit.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.ButtonEdit.Tag = "BE";
			this.ButtonEdit.Text = "Map Editor";
			this.ButtonEdit.ToolTipText = "Allows you to create your own maps of the games";
			// 
			// MapEditor
			// 
			this.MapEditor.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuEditKL,
																					  this.MenuEditA8});
			// 
			// MenuEditKL
			// 
			this.MenuEditKL.Index = 0;
			this.MenuEditKL.Text = "Knight Lore";
			this.MenuEditKL.Click += new System.EventHandler(this.MenuEditKL_Click);
			// 
			// MenuEditA8
			// 
			this.MenuEditA8.Index = 1;
			this.MenuEditA8.Text = "Alien 8";
			this.MenuEditA8.Click += new System.EventHandler(this.MenuEditA8_Click);
			// 
			// ButtonItems
			// 
			this.ButtonItems.Tag = "O";
			this.ButtonItems.Text = "View Gfx";
			// 
			// RenderRoom
			// 
			this.RenderRoom.Tag = "RR";
			this.RenderRoom.Text = "Render Rooom...";
			// 
			// RenderMap
			// 
			this.RenderMap.Tag = "RM";
			this.RenderMap.Text = "Render Map...";
			// 
			// ButtonHelp
			// 
			this.ButtonHelp.Tag = "H";
			this.ButtonHelp.Text = "Help";
			// 
			// toolBarButton1
			// 
			this.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// ButtonExit
			// 
			this.ButtonExit.Tag = "X";
			this.ButtonExit.Text = "Exit";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(10, 398);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(85, 18);
			this.label8.TabIndex = 27;
			this.label8.Text = "Have Specials";
			// 
			// ListSpecials
			// 
			this.ListSpecials.Location = new System.Drawing.Point(9, 416);
			this.ListSpecials.Name = "ListSpecials";
			this.ListSpecials.Size = new System.Drawing.Size(75, 225);
			this.ListSpecials.TabIndex = 26;
			this.ListSpecials.SelectedIndexChanged += new System.EventHandler(this.ListSpecials_SelectedIndexChanged);
			// 
			// LabelOffset
			// 
			this.LabelOffset.Location = new System.Drawing.Point(130, 78);
			this.LabelOffset.Name = "LabelOffset";
			this.LabelOffset.Size = new System.Drawing.Size(32, 12);
			this.LabelOffset.TabIndex = 22;
			this.LabelOffset.Text = "?";
			// 
			// LabelFG
			// 
			this.LabelFG.Location = new System.Drawing.Point(607, 78);
			this.LabelFG.Name = "LabelFG";
			this.LabelFG.Size = new System.Drawing.Size(56, 12);
			this.LabelFG.TabIndex = 20;
			this.LabelFG.Text = "?";
			// 
			// LabelBG
			// 
			this.LabelBG.Location = new System.Drawing.Point(503, 78);
			this.LabelBG.Name = "LabelBG";
			this.LabelBG.Size = new System.Drawing.Size(56, 12);
			this.LabelBG.TabIndex = 19;
			this.LabelBG.Text = "?";
			// 
			// LabelAttr
			// 
			this.LabelAttr.Location = new System.Drawing.Point(394, 78);
			this.LabelAttr.Name = "LabelAttr";
			this.LabelAttr.Size = new System.Drawing.Size(56, 12);
			this.LabelAttr.TabIndex = 18;
			this.LabelAttr.Text = "?";
			// 
			// LabelType
			// 
			this.LabelType.Location = new System.Drawing.Point(218, 78);
			this.LabelType.Name = "LabelType";
			this.LabelType.Size = new System.Drawing.Size(166, 12);
			this.LabelType.TabIndex = 17;
			this.LabelType.Text = "?";
			// 
			// LabelID
			// 
			this.LabelID.Location = new System.Drawing.Point(23, 78);
			this.LabelID.Name = "LabelID";
			this.LabelID.Size = new System.Drawing.Size(33, 12);
			this.LabelID.TabIndex = 16;
			this.LabelID.Text = "?";
			// 
			// ListboxRooms
			// 
			this.ListboxRooms.Location = new System.Drawing.Point(9, 118);
			this.ListboxRooms.Name = "ListboxRooms";
			this.ListboxRooms.Size = new System.Drawing.Size(75, 264);
			this.ListboxRooms.TabIndex = 9;
			this.ListboxRooms.SelectedIndexChanged += new System.EventHandler(this.ListboxRooms_SelectedIndexChanged);
			// 
			// LabelRooms
			// 
			this.LabelRooms.Location = new System.Drawing.Point(9, 105);
			this.LabelRooms.Name = "LabelRooms";
			this.LabelRooms.Size = new System.Drawing.Size(100, 11);
			this.LabelRooms.TabIndex = 8;
			this.LabelRooms.Text = "Rooms";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(741, 309);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(206, 18);
			this.label12.TabIndex = 42;
			this.label12.Text = "Map (Click on cell to change room)";
			// 
			// glList
			// 
			this.glList.AllowColumnResize = true;
			this.glList.AllowMultiselect = false;
			this.glList.AlternateBackground = System.Drawing.Color.DarkGreen;
			this.glList.AlternatingColors = false;
			this.glList.AutoHeight = true;
			this.glList.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.glList.BackgroundStretchToFit = true;
			glColumn1.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn1.CheckBoxes = false;
			glColumn1.ImageIndex = -1;
			glColumn1.Name = "TheImage";
			glColumn1.NumericSort = false;
			glColumn1.Text = "Block";
			glColumn1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn1.Width = 70;
			glColumn2.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn2.CheckBoxes = false;
			glColumn2.ImageIndex = -1;
			glColumn2.Name = "Name";
			glColumn2.NumericSort = false;
			glColumn2.Text = "Name";
			glColumn2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn2.Width = 170;
			glColumn3.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn3.CheckBoxes = false;
			glColumn3.ImageIndex = -1;
			glColumn3.Name = "x";
			glColumn3.NumericSort = false;
			glColumn3.Text = "x";
			glColumn3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn3.Width = 35;
			glColumn4.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn4.CheckBoxes = false;
			glColumn4.ImageIndex = -1;
			glColumn4.Name = "y";
			glColumn4.NumericSort = false;
			glColumn4.Text = "y";
			glColumn4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn4.Width = 35;
			glColumn5.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn5.CheckBoxes = false;
			glColumn5.ImageIndex = -1;
			glColumn5.Name = "z";
			glColumn5.NumericSort = false;
			glColumn5.Text = "z";
			glColumn5.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn5.Width = 35;
			glColumn6.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn6.CheckBoxes = false;
			glColumn6.ImageIndex = -1;
			glColumn6.Name = "xoffset";
			glColumn6.NumericSort = false;
			glColumn6.Text = "X Offset";
			glColumn6.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn6.Width = 50;
			glColumn7.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn7.CheckBoxes = false;
			glColumn7.ImageIndex = -1;
			glColumn7.Name = "yoffset";
			glColumn7.NumericSort = false;
			glColumn7.Text = "Y Offset";
			glColumn7.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn7.Width = 50;
			glColumn8.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn8.CheckBoxes = false;
			glColumn8.ImageIndex = -1;
			glColumn8.Name = "zoffset";
			glColumn8.NumericSort = false;
			glColumn8.Text = "Z Offset";
			glColumn8.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn8.Width = 50;
			glColumn9.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn9.CheckBoxes = false;
			glColumn9.ImageIndex = -1;
			glColumn9.Name = "z_only";
			glColumn9.NumericSort = false;
			glColumn9.Text = "Movement";
			glColumn9.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn9.Width = 65;
			glColumn10.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn10.CheckBoxes = false;
			glColumn10.ImageIndex = -1;
			glColumn10.Name = "extra";
			glColumn10.NumericSort = false;
			glColumn10.Text = "Extra Information";
			glColumn10.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn10.Width = 500;
			glColumn11.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn11.CheckBoxes = false;
			glColumn11.ImageIndex = -1;
			glColumn11.Name = "ControlBlockExtensionIndex";
			glColumn11.NumericSort = false;
			glColumn11.Text = "Column";
			glColumn11.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn11.Width = 15;
			glColumn12.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn12.CheckBoxes = false;
			glColumn12.ImageIndex = -1;
			glColumn12.Name = "BlockExtensionIndex";
			glColumn12.NumericSort = false;
			glColumn12.Text = "Column";
			glColumn12.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn12.Width = 15;
			this.glList.Columns.AddRange(new GlacialComponents.Controls.GLColumn[] {
																					   glColumn1,
																					   glColumn2,
																					   glColumn3,
																					   glColumn4,
																					   glColumn5,
																					   glColumn6,
																					   glColumn7,
																					   glColumn8,
																					   glColumn9,
																					   glColumn10,
																					   glColumn11,
																					   glColumn12});
			this.glList.ControlStyle = GlacialComponents.Controls.GLControlStyles.Normal;
			this.glList.FullRowSelect = true;
			this.glList.GridColor = System.Drawing.Color.LightGray;
			this.glList.GridLines = GlacialComponents.Controls.GLGridLines.gridBoth;
			this.glList.GridLineStyle = GlacialComponents.Controls.GLGridLineStyles.gridSolid;
			this.glList.GridTypes = GlacialComponents.Controls.GLGridTypes.gridOnExists;
			this.glList.HeaderHeight = 22;
			this.glList.HeaderVisible = true;
			this.glList.HeaderWordWrap = false;
			this.glList.HotColumnTracking = false;
			this.glList.HotItemTracking = false;
			this.glList.HotTrackingColor = System.Drawing.Color.LightGray;
			this.glList.HoverEvents = false;
			this.glList.HoverTime = 1;
			this.glList.ImageList = this.ImageListFG;
			this.glList.ItemHeight = 17;
			this.glList.ItemWordWrap = false;
			this.glList.Location = new System.Drawing.Point(89, 113);
			this.glList.Name = "glList";
			this.glList.Selectable = true;
			this.glList.SelectedTextColor = System.Drawing.Color.White;
			this.glList.SelectionColor = System.Drawing.Color.DarkBlue;
			this.glList.ShowBorder = true;
			this.glList.ShowFocusRect = false;
			this.glList.Size = new System.Drawing.Size(646, 530);
			this.glList.SortType = GlacialComponents.Controls.SortTypes.InsertionSort;
			this.glList.SuperFlatHeaderColor = System.Drawing.Color.White;
			this.glList.TabIndex = 45;
			this.glList.Text = "glacialList1";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(584, 61);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(120, 16);
			this.label6.TabIndex = 15;
			this.label6.Text = "Unique Blocks";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(479, 61);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(120, 16);
			this.label7.TabIndex = 14;
			this.label7.Text = "Background Items";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(360, 61);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 16);
			this.label1.TabIndex = 13;
			this.label1.Text = "Attributes (colour)";
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.Location = new System.Drawing.Point(15, 61);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(67, 16);
			this.label10.TabIndex = 10;
			this.label10.Text = "ID/Location";
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label11.Location = new System.Drawing.Point(217, 61);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(120, 16);
			this.label11.TabIndex = 12;
			this.label11.Text = "Room Size Type";
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label13.Location = new System.Drawing.Point(87, 61);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(120, 16);
			this.label13.TabIndex = 11;
			this.label13.Text = "Offset to Next Room";
			// 
			// glMap
			// 
			this.glMap.AllowColumnResize = false;
			this.glMap.AllowMultiselect = false;
			this.glMap.AlternateBackground = System.Drawing.Color.DarkGreen;
			this.glMap.AlternatingColors = false;
			this.glMap.AutoHeight = true;
			this.glMap.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.glMap.BackgroundStretchToFit = true;
			this.glMap.ControlStyle = GlacialComponents.Controls.GLControlStyles.Normal;
			this.glMap.Cursor = System.Windows.Forms.Cursors.Default;
			this.glMap.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.glMap.FullRowSelect = false;
			this.glMap.GridColor = System.Drawing.Color.LightGray;
			this.glMap.GridLines = GlacialComponents.Controls.GLGridLines.gridBoth;
			this.glMap.GridLineStyle = GlacialComponents.Controls.GLGridLineStyles.gridSolid;
			this.glMap.GridTypes = GlacialComponents.Controls.GLGridTypes.gridOnExists;
			this.glMap.HeaderHeight = 22;
			this.glMap.HeaderVisible = true;
			this.glMap.HeaderWordWrap = false;
			this.glMap.HotColumnTracking = false;
			this.glMap.HotItemTracking = false;
			this.glMap.HotTrackingColor = System.Drawing.Color.LightGray;
			this.glMap.HoverEvents = false;
			this.glMap.HoverTime = 1;
			this.glMap.ImageList = null;
			this.glMap.ItemHeight = 17;
			this.glMap.ItemWordWrap = false;
			this.glMap.Location = new System.Drawing.Point(741, 326);
			this.glMap.Name = "glMap";
			this.glMap.Selectable = true;
			this.glMap.SelectedTextColor = System.Drawing.Color.Transparent;
			this.glMap.SelectionColor = System.Drawing.Color.RosyBrown;
			this.glMap.ShowBorder = true;
			this.glMap.ShowFocusRect = true;
			this.glMap.Size = new System.Drawing.Size(277, 326);
			this.glMap.SortType = GlacialComponents.Controls.SortTypes.None;
			this.glMap.SuperFlatHeaderColor = System.Drawing.Color.White;
			this.glMap.TabIndex = 46;
			this.glMap.Text = "glacialList1";
			this.glMap.ItemChangedEvent += new GlacialComponents.Controls.ChangedEventHandler(this.glMap_ItemChangedEvent);
			// 
			// LabelRoomLinks
			// 
			this.LabelRoomLinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelRoomLinks.Location = new System.Drawing.Point(15, 91);
			this.LabelRoomLinks.Name = "LabelRoomLinks";
			this.LabelRoomLinks.Size = new System.Drawing.Size(473, 16);
			this.LabelRoomLinks.TabIndex = 47;
			this.LabelRoomLinks.Text = "East: ";
			// 
			// glSpecials
			// 
			this.glSpecials.AllowColumnResize = true;
			this.glSpecials.AllowMultiselect = false;
			this.glSpecials.AlternateBackground = System.Drawing.Color.DarkGreen;
			this.glSpecials.AlternatingColors = false;
			this.glSpecials.AutoHeight = true;
			this.glSpecials.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.glSpecials.BackgroundStretchToFit = true;
			glColumn13.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn13.CheckBoxes = false;
			glColumn13.ImageIndex = -1;
			glColumn13.Name = "Block";
			glColumn13.NumericSort = false;
			glColumn13.Text = "Block";
			glColumn13.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn13.Width = 40;
			glColumn14.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn14.CheckBoxes = false;
			glColumn14.ImageIndex = -1;
			glColumn14.Name = "Name";
			glColumn14.NumericSort = false;
			glColumn14.Text = "Name";
			glColumn14.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn14.Width = 100;
			glColumn15.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn15.CheckBoxes = false;
			glColumn15.ImageIndex = -1;
			glColumn15.Name = "Flags";
			glColumn15.NumericSort = false;
			glColumn15.Text = "Flags";
			glColumn15.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn15.Width = 50;
			glColumn16.ActivatedEmbeddedType = GlacialComponents.Controls.GLActivatedEmbeddedTypes.None;
			glColumn16.CheckBoxes = false;
			glColumn16.ImageIndex = -1;
			glColumn16.Name = "Description";
			glColumn16.NumericSort = false;
			glColumn16.Text = "Description";
			glColumn16.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
			glColumn16.Width = 300;
			this.glSpecials.Columns.AddRange(new GlacialComponents.Controls.GLColumn[] {
																						   glColumn13,
																						   glColumn14,
																						   glColumn15,
																						   glColumn16});
			this.glSpecials.ControlStyle = GlacialComponents.Controls.GLControlStyles.Normal;
			this.glSpecials.FullRowSelect = true;
			this.glSpecials.GridColor = System.Drawing.Color.LightGray;
			this.glSpecials.GridLines = GlacialComponents.Controls.GLGridLines.gridBoth;
			this.glSpecials.GridLineStyle = GlacialComponents.Controls.GLGridLineStyles.gridSolid;
			this.glSpecials.GridTypes = GlacialComponents.Controls.GLGridTypes.gridOnExists;
			this.glSpecials.HeaderHeight = 22;
			this.glSpecials.HeaderVisible = true;
			this.glSpecials.HeaderWordWrap = false;
			this.glSpecials.HotColumnTracking = false;
			this.glSpecials.HotItemTracking = false;
			this.glSpecials.HotTrackingColor = System.Drawing.Color.LightGray;
			this.glSpecials.HoverEvents = false;
			this.glSpecials.HoverTime = 1;
			this.glSpecials.ImageList = this.ImageListSP;
			this.glSpecials.ItemHeight = 17;
			this.glSpecials.ItemWordWrap = false;
			this.glSpecials.Location = new System.Drawing.Point(738, 112);
			this.glSpecials.Name = "glSpecials";
			this.glSpecials.Selectable = true;
			this.glSpecials.SelectedTextColor = System.Drawing.Color.White;
			this.glSpecials.SelectionColor = System.Drawing.Color.DarkBlue;
			this.glSpecials.ShowBorder = true;
			this.glSpecials.ShowFocusRect = false;
			this.glSpecials.Size = new System.Drawing.Size(276, 193);
			this.glSpecials.SortType = GlacialComponents.Controls.SortTypes.InsertionSort;
			this.glSpecials.SuperFlatHeaderColor = System.Drawing.Color.White;
			this.glSpecials.TabIndex = 48;
			this.glSpecials.Text = "glacialList1";
			// 
			// ImageListSP
			// 
			this.ImageListSP.ImageSize = new System.Drawing.Size(32, 32);
			this.ImageListSP.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(742, 93);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(63, 18);
			this.label2.TabIndex = 49;
			this.label2.Text = "Specials";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(756, 344);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(206, 246);
			this.label3.TabIndex = 50;
			this.label3.Text = "Due to the way in which the rooms are navigated to, i.e. it does not use a standa" +
				"rd grid (like in Alien8 and KnightLore), a map cannot be generated.  I\'m sure it" +
				" can, but I haven\'t the time :)";
			// 
			// PanelEditMode
			// 
			this.PanelEditMode.Controls.Add(this.ButtonRefresh);
			this.PanelEditMode.Controls.Add(this.EditRow);
			this.PanelEditMode.Controls.Add(this.ButtonCreateGame);
			this.PanelEditMode.Controls.Add(this.ButtonAddRow);
			this.PanelEditMode.Controls.Add(this.ButtonDeleteRow);
			this.PanelEditMode.Controls.Add(this.LabelSizings);
			this.PanelEditMode.Location = new System.Drawing.Point(89, 657);
			this.PanelEditMode.Name = "PanelEditMode";
			this.PanelEditMode.Size = new System.Drawing.Size(925, 41);
			this.PanelEditMode.TabIndex = 55;
			this.PanelEditMode.Visible = false;
			// 
			// ButtonRefresh
			// 
			this.ButtonRefresh.Location = new System.Drawing.Point(441, 8);
			this.ButtonRefresh.Name = "ButtonRefresh";
			this.ButtonRefresh.Size = new System.Drawing.Size(95, 23);
			this.ButtonRefresh.TabIndex = 60;
			this.ButtonRefresh.Text = "&Refresh/Save";
			this.ButtonRefresh.Click += new System.EventHandler(this.ButtonRefresh_Click);
			// 
			// EditRow
			// 
			this.EditRow.Location = new System.Drawing.Point(536, 8);
			this.EditRow.Name = "EditRow";
			this.EditRow.Size = new System.Drawing.Size(95, 23);
			this.EditRow.TabIndex = 59;
			this.EditRow.Text = "&Edit Row";
			this.EditRow.Click += new System.EventHandler(this.EditRow_Click);
			// 
			// ButtonCreateGame
			// 
			this.ButtonCreateGame.Location = new System.Drawing.Point(821, 8);
			this.ButtonCreateGame.Name = "ButtonCreateGame";
			this.ButtonCreateGame.Size = new System.Drawing.Size(95, 23);
			this.ButtonCreateGame.TabIndex = 58;
			this.ButtonCreateGame.Text = "Create Game";
			this.ButtonCreateGame.Click += new System.EventHandler(this.ButtonCreateGame_Click);
			// 
			// ButtonAddRow
			// 
			this.ButtonAddRow.Location = new System.Drawing.Point(726, 8);
			this.ButtonAddRow.Name = "ButtonAddRow";
			this.ButtonAddRow.Size = new System.Drawing.Size(95, 23);
			this.ButtonAddRow.TabIndex = 57;
			this.ButtonAddRow.Text = "&Insert Row";
			this.ButtonAddRow.Click += new System.EventHandler(this.ButtonAddRow_Click);
			// 
			// ButtonDeleteRow
			// 
			this.ButtonDeleteRow.Location = new System.Drawing.Point(631, 8);
			this.ButtonDeleteRow.Name = "ButtonDeleteRow";
			this.ButtonDeleteRow.Size = new System.Drawing.Size(95, 23);
			this.ButtonDeleteRow.TabIndex = 56;
			this.ButtonDeleteRow.Text = "&Delete Row";
			this.ButtonDeleteRow.Click += new System.EventHandler(this.ButtonDeleteRow_Click);
			// 
			// LabelSizings
			// 
			this.LabelSizings.Location = new System.Drawing.Point(4, 13);
			this.LabelSizings.Name = "LabelSizings";
			this.LabelSizings.Size = new System.Drawing.Size(419, 19);
			this.LabelSizings.TabIndex = 55;
			this.LabelSizings.Text = "Bytes in Location Data";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1016, 711);
			this.Controls.Add(this.PanelEditMode);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.glSpecials);
			this.Controls.Add(this.LabelRoomLinks);
			this.Controls.Add(this.glMap);
			this.Controls.Add(this.glList);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.ListSpecials);
			this.Controls.Add(this.LabelOffset);
			this.Controls.Add(this.LabelFG);
			this.Controls.Add(this.LabelBG);
			this.Controls.Add(this.LabelAttr);
			this.Controls.Add(this.LabelType);
			this.Controls.Add(this.LabelID);
			this.Controls.Add(this.ListboxRooms);
			this.Controls.Add(this.LabelRooms);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label3);
			this.Name = "MainForm";
			this.Text = "Ultimate Iso Convert";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.PanelEditMode.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void ListboxRooms_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			RoomChange();
		}

		private void RoomChange()
		{
			Hashtable hl;
			hl=new Hashtable();
			this.glList.Items.Clear();
			this.ImageListFG.Images.Clear();
			Room lRoom=(Room)myData.Rooms[this.ListboxRooms.SelectedIndex];

			this.LabelRoomLinks.Text="Room Links from here: ";
			if (lRoom.LinkRoomNorth!=-1)
				this.LabelRoomLinks.Text+="North: "+lRoom.LinkRoomNorth+". ";
			if (lRoom.LinkRoomEast!=-1)
				this.LabelRoomLinks.Text+="East: "+lRoom.LinkRoomEast+". ";
			if (lRoom.LinkRoomSouth!=-1)
				this.LabelRoomLinks.Text+="South: "+lRoom.LinkRoomSouth+". ";
			if (lRoom.LinkRoomWest!=-1)
				this.LabelRoomLinks.Text+="West: "+lRoom.LinkRoomWest+". ";

			//debug code for a8 until determine room size proper
			if (lRoom.Size<myData.RoomSizes.Count)
				this.LabelType.Text=lRoom.Size.ToString() + ". Size in Cells: " +((RoomSize)myData.RoomSizes[lRoom.Size]).description;
			else
				//should not get here
				this.LabelType.Text=lRoom.Size.ToString()+": ERROR";
			this.LabelOffset.Text=lRoom.ActualOffset.ToString();
			this.LabelID.Text=lRoom.ID.ToString();
			this.LabelFG.Text=lRoom.ForegroundItems.Count.ToString();
			this.LabelBG.Text=lRoom.BackgroundItems.Count.ToString();
			this.LabelAttr.Text=lRoom.Attribute.ToString();
			//background
			BlockDescriptor tempBlock;
			int locationx,locationy,locationz;
			//background as there are just a few simply add the bitmaps
			//without checking for duplicates.
			foreach(int BGItem in lRoom.BackgroundItems)
			{
				tempBlock=myData.FindBlockFromNumber(2,BGItem);
				try 
				{
					if(tempBlock.bmp!="")
						this.ImageListFG.Images.Add(new Bitmap("images\\"+tempBlock.bmp));
				} 
				catch 
				{
					this.ImageListFG.Images.Add(new Bitmap("images\\unknown.gif"));
					System.Windows.Forms.MessageBox.Show(this,"Could not open bitmap: " + "images\\"+tempBlock.bmp);
				}
				locationx=tempBlock.x;
				locationy=tempBlock.y;
				locationz=tempBlock.z;
				if(locationx+locationy+locationz>0)
				{
					if(locationx>=0x80) locationx-=0x80;
					if(locationy>=0x80) locationy-=0x80;
					if(locationz>=0x80) locationz-=0x80;
				}
				GlacialComponents.Controls.GLItem gli=new GlacialComponents.Controls.GLItem();
				GlacialComponents.Controls.GLSubItem gls;
				gls=new GlacialComponents.Controls.GLSubItem();
				gls.ImageIndex=(this.ImageListFG.Images.Count-1);
				gli.SubItems.Add(gls);

				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=tempBlock.Name; //name
				gli.SubItems.Add(gls);

				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=locationx.ToString(); //x
				gli.SubItems.Add(gls);
				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=locationy.ToString(); //y
				gli.SubItems.Add(gls);
				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=locationz.ToString(); //z
				gli.SubItems.Add(gls);

				gli.BackColor=System.Drawing.Color.Bisque;
				glList.Items.Add(gli);
			}

			int offsetimages=this.ImageListFG.Images.Count;
			hl.Clear();
			int j=0;
			foreach(Block myBlock in lRoom.ForegroundItems)
			{
				BlockDescriptor myBD=myData.FindBlockFromNumber(1,myBlock.Type);
				//add image to hash table if valid
				if(myBD.bmp!="")
				{
					if(!hl.ContainsKey(myBlock.Type))
					{
						try
						{
							this.ImageListFG.Images.Add(new Bitmap("images\\"+myBD.bmp));
							hl.Add(myBlock.Type,this.ImageListFG.Images.Count-1);
						}
						catch
						{
							this.ImageListFG.Images.Add(new Bitmap("images\\unknown.gif"));
							System.Windows.Forms.MessageBox.Show(this,"The image images\\"+myBD.bmp+" was not found!");
							hl.Add(myBlock.Type,this.ImageListFG.Images.Count-1);
						}
					}
				}

				string myname=myBD.Name+" ("+myBlock.Type+")";
				int i=0;
				foreach(BlockLocation myLocation in myBlock.BlockLocations)
				{
					GlacialComponents.Controls.GLItem gli=new GlacialComponents.Controls.GLItem();
					GlacialComponents.Controls.GLSubItem gls;
					gls=new GlacialComponents.Controls.GLSubItem();
					if(hl.ContainsKey(myBlock.Type))
						gls.ImageIndex=(int)hl[myBlock.Type]; //block
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=myname; //name
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=myLocation.x.ToString();		//x
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=myLocation.y.ToString();		//y
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=myLocation.z.ToString();		//z
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					if((myBD.Offsetxyz&0x1)!=0) gls.Text="Half block";	//xoffset
					else gls.Text="";
					gli.SubItems.Add(gls);
					
					gls=new GlacialComponents.Controls.GLSubItem();
					if((myBD.Offsetxyz&0x2)!=0) gls.Text="Half block";	//yoffset
					else gls.Text="";
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=(myBD.Offsetxyz>>2).ToString();		//z offset
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					if(myBD.MovementType==1) gls.Text="Z";		//z only
					else gls.Text="Free";
					gli.SubItems.Add(gls);

					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=myBD.Extra;		//extra 
					gli.SubItems.Add(gls);

					//control block (z offset) extension
					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=j.ToString();
					gli.SubItems.Add(gls);
					//block extension (using blocks after limit)
					gls=new GlacialComponents.Controls.GLSubItem();
					gls.Text=i.ToString();
					gli.SubItems.Add(gls);

					glList.Items.Add(gli);
					i++;
				}
				j++;
			}

			if(hl.Count!=this.ImageListFG.Images.Count-offsetimages) System.Windows.Forms.MessageBox.Show(this,"Not all foreground images could be found for display in the treeview");
			//objects

			foreach(Block myBlock in lRoom.RandomItems)
			{
				string myname="Random special";
				foreach(BlockLocation myLocation in myBlock.BlockLocations)
				{
					GlacialComponents.Controls.GLItem gli=new GlacialComponents.Controls.GLItem();

					gli.SubItems[1].Text=myname;
					gli.SubItems[2].Text=myLocation.x.ToString();
					gli.SubItems[3].Text=myLocation.y.ToString();
					gli.SubItems[4].Text=myLocation.z.ToString();
					gli.SubItems[8].Text="Free";
					gli.SubItems[9].Text="placed at runtime";
					glList.Items.Add(gli);

				}
			}
			glList.Refresh();
			UpdateItem();		
		}

		private void UpdateItem()
		{
			try
			{
				int founditem=this.ListSpecials.FindStringExact(this.ListboxRooms.Text);
				int row,column;
				if(founditem>=0)
					this.ListSpecials.SelectedIndex=founditem;

				char[] delims=" ".ToCharArray();
				string[] bob=ListboxRooms.Text.Split(delims);
				int bob2=Convert.ToInt32(bob[1],10);
				column=bob2%myData.MapWidth;
				if(bob2<myData.MapWidth) row=0;
				else row=(bob2-column)/myData.MapWidth;
				row=15-row;	//start from bottom
				column++;	//ignore column 0 as its the title
				switch(myData.Prefixname)
				{
					case "kl":
						if(bob2==47 || bob2==68 || bob2==179 || bob2==143)
							this.glMap.Items[row].SubItems[column].BackColor=Color.Purple;
						else
							this.glMap.Items[row].SubItems[column].BackColor=Color.YellowGreen;
						break;
					case "a8":
						if(bob2==19 || bob2==78 || bob2==136 || bob2==215)
							this.glMap.Items[row].SubItems[column].BackColor=Color.Purple;
						else
							this.glMap.Items[row].SubItems[column].BackColor=Color.YellowGreen;
						break;
					default:
						this.glMap.Items[row].SubItems[column].BackColor=Color.YellowGreen;
						break;
				}

				//this.glMap.Items[row].SubItems[column].BackColor=Color.YellowGreen;
				this.LastItemElement=glMap.Items[row].SubItems[column];
			}
			catch
			{
				//probably not found!
			}

		}
		private void DrawPurples()
		{
			if(myData.Prefixname=="kl")
			{
				this.glMap.Items[15-(47/16)].SubItems[(47%16)+1].BackColor=Color.Purple;
				this.glMap.Items[15-(68/16)].SubItems[(68%16)+1].BackColor=Color.Purple;
				this.glMap.Items[15-(179/16)].SubItems[(179%16)+1].BackColor=Color.Purple;
				this.glMap.Items[15-(143/16)].SubItems[(143%16)+1].BackColor=Color.Purple;
			}
			if(myData.Prefixname=="a8")
			{
			}
		}

		private void ToolbarMain_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			switch((string)e.Button.Tag)
			{
				case "L":
				case "BE":
					MessageBox.Show(this,"Select the drop down to choose your map.");
					break;
				case "H":
					SplashScreen splashscreen=new SplashScreen(true);
					splashscreen.ShowDialog(this);
					break;
				case "X":
					if(!CheckSave()) return;
					this.Close();
					Application.Exit();
					break;
				case "O":
					images imagescreen=new images();
					imagescreen.DoList(myData);
					imagescreen.ShowDialog(this);
					break;
				default:
					MessageBox.Show(this,"You have selected a menu not yet defined!");
					break;
			}
		}

		private void MenuKnightlore_Click(object sender, System.EventArgs e)
		{
			this.PanelEditMode.Visible=false;
			myData.LoadData("maps\\kl_map.txt","kl");
			//convert loaded data into internal format
			if(!myData.TransformData()) MessageBox.Show(this,"Errors occurred in the data loading.  Consult the debug or raw output files (search for ERROR)");
			myData.WriteToFile();
			myData.XMLOutput("Knight Lore",new int[]{0x2F,0x044,0x0B3,0x08F});
			UpdateRoomDisplay();

			UpdateSpecials();
			MessageBox.Show(this,"Generated data files are stored in the 'outputs' directory");
		}
		private bool CheckSave()
		{
			if(!EditDirty) return true;
			if(MessageBox.Show("Data has changed, select Yes to continue and abort any changes. Otherwise select No then click refresh/save","Continue",MessageBoxButtons.YesNo)==DialogResult.No)
				return false;
			else
				return true;
		}
		private void MenuEditKL_Click(object sender, System.EventArgs e)
		{
			if(!CheckSave()) return;
			SelectMap newMap=new SelectMap();
			if(newMap.PopulateData("kl"))
			{
				newMap.ShowDialog(this);
			}
			string mapname=newMap.Tag.ToString();
			newMap.Close();
			if(mapname!="")
			{
				this.PanelEditMode.Visible=true;
				myData.LoadData("maps\\kl_map.txt","kl",mapname);
				//do all the outputs as normal
				//convert loaded data into internal format
				if(!myData.TransformData()) MessageBox.Show(this,"Errors occurred in the data loading.  Consult the debug or raw output files (search for ERROR)");
				myData.WriteToFile();
				myData.XMLOutput("Knight Lore using "+mapname,new int[]{0x2F,0x044,0x0B3,0x08F});
				UpdateRoomDisplay();

				UpdateSpecials();
				UpdateSize();
				MessageBox.Show(this,"Generated data files are stored in the 'outputs' directory for this custom game");
			}
		}

		private void MenuAlien8_Click(object sender, System.EventArgs e)
		{
			if(!CheckSave()) return;
			this.PanelEditMode.Visible=false;
			myData.LoadData("maps\\a8_map.txt","a8");
			//convert loaded data into internal format
			if(!myData.TransformData()) MessageBox.Show(this,"Errors occurred in the data loading.  Consult the debug or raw output files (search for ERROR)");
			myData.WriteToFile();
			myData.XMLOutput("Alien 8",new int[]{19,78,136,215});
			UpdateRoomDisplay();

			UpdateSpecials();
			MessageBox.Show(this,"Generated data files are stored in the 'outputs' directory");
		}
		private void MenuEditA8_Click(object sender, System.EventArgs e)
		{
			SelectMap newMap=new SelectMap();
			if(newMap.PopulateData("a8"))
			{
				newMap.ShowDialog(this);
			}
			string mapname=newMap.Tag.ToString();
			newMap.Close();
			if(mapname!="")
			{
				this.PanelEditMode.Visible=true;
				myData.LoadData("maps\\a8_map.txt","a8",mapname);
				//do all the outputs as normal
				//convert loaded data into internal format
				if(!myData.TransformData()) MessageBox.Show(this,"Errors occurred in the data loading.  Consult the debug or raw output files (search for ERROR)");
				myData.WriteToFile();
				myData.XMLOutput("Alien 8 using "+mapname,new int[]{19,78,136,215});
				UpdateRoomDisplay();

				UpdateSpecials();
				UpdateSize();
				MessageBox.Show(this,"Generated data files are stored in the 'outputs' directory for this custom game");
			}
		}


		private void MenuPentagram_Click(object sender, System.EventArgs e)
		{
			this.PanelEditMode.Visible=false;
			myData.LoadData("maps\\pg_map.txt","pg");
			//convert loaded data into internal format
			if(!myData.TransformData()) MessageBox.Show(this,"Errors occurred in the data loading.  Consult the debug or raw output files (search for ERROR)");
			myData.WriteToFile();
			myData.XMLOutput("Pentagram",new int[]{0x33,0x5C,0x64,0x0C});
			UpdateRoomDisplay();

			UpdateSpecials();
			UpdateSize();
			MessageBox.Show(this,"Generated data files are stored in the 'outputs' directory");
		}

		private void ListSpecials_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.ListboxRooms.SelectedIndex=this.ListboxRooms.FindString(this.ListSpecials.Text);
		}

		private void UpdateSize()
		{
			if(!RefreshRequired)
				this.LabelSizings.Text=myData.AdditionalLocation+": "+ "Original Game Bytes: "+myData.OriginalLocationDataSize.ToString()+", This game Bytes: "+myData.CurrentLocationDataSize.ToString()+". Spare bytes: "+(myData.OriginalLocationDataSize-myData.CurrentLocationDataSize).ToString();
			else
				this.LabelSizings.Text="Original Game Bytes: "+myData.OriginalLocationDataSize.ToString()+", This game Bytes: refresh required";

		}

		private void UpdateSpecials()
		{
			this.ListSpecials.Items.Clear();
			foreach(Room roomval in myData.Rooms)
				foreach(object special in roomval.RandomItems)
				{
					this.ListSpecials.Items.Add("Room " + roomval.ID);
				}

			this.glSpecials.Items.Clear();
			GlacialComponents.Controls.GLItem gli;
			GlacialComponents.Controls.GLSubItem gls;
			this.ImageListSP.Images.Clear();
			for(int i=0; i<myData.Specials.Count;i++)
			{
				BlockSpecial special=(BlockSpecial)myData.Specials[i];
				try
				{
					this.ImageListSP.Images.Add(new Bitmap("images\\"+special.bmp));
				}
				catch
				{
					this.ImageListSP.Images.Add(new Bitmap("images\\unknown.gif"));
				}
			}
			this.ImageListSP.Images.Add(new Bitmap("images\\unknown.gif"));

			for(int i=0; i<myData.Specials.Count;i++)
			{
				gli=new GlacialComponents.Controls.GLItem();

				BlockSpecial special=(BlockSpecial)myData.Specials[i];
				gls=new GlacialComponents.Controls.GLSubItem();
				try 
				{
					if(special.bmp!="")
						gls.ImageIndex=(i);
				}
				catch
				{
					gls.ImageIndex=(myData.Specials.Count-1);
				}
				gli.SubItems.Add(gls);

				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=special.Name;
				gli.SubItems.Add(gls);
				gls=new GlacialComponents.Controls.GLSubItem();
				switch(special.flag)
				{
					case 0:
						gls.Text="None";
						break;
					case 8:
						gls.Text="Special";
						break;
					case 16:
						gls.Text="Player";
						break;
					case 2:
						gls.Text="Grid";
						break;
					case 3:
						gls.Text="Free";
						break;
					default:
						gls.Text=special.flag.ToString();
						break;
				}
				gli.SubItems.Add(gls);
				gls=new GlacialComponents.Controls.GLSubItem();
				gls.Text=special.Description;
				gli.SubItems.Add(gls);

				this.glSpecials.Items.Add(gli);
			}
			glSpecials.Refresh();
		}

		private void UpdateRoomDisplay()
		{
			if(this.myData.DoingTwoByteBackground) glMap.Visible=false;
			else glMap.Visible=true;

			this.ListboxRooms.Items.Clear();
			this.LabelRooms.Text="Rooms: " +myData.Rooms.Count;
			foreach(Room eachRoom in myData.Rooms)
				this.ListboxRooms.Items.Add("Room " +eachRoom.ID);

			if(this.ListboxRooms.Items.Count>0)
				this.ListboxRooms.SelectedIndex=0;

			//do map
			this.glMap.Items.Clear();
			this.glMap.Columns.Clear();
			GlacialComponents.Controls.GLItem gli;
			GlacialComponents.Controls.GLSubItem gls;
			int EndRow=((Room)myData.Rooms[myData.Rooms.Count-1]).ID/myData.MapWidth;
			for(int i=0;i<=myData.MapWidth;i++) 
			{
				if(i!=0) this.glMap.Columns.Add((i-1).ToString(),this.glMap.Width/(myData.MapWidth+1));
				else this.glMap.Columns.Add("",this.glMap.Width/(myData.MapWidth+1));

			}

			for(int i=0;i<=EndRow;i++)
			{
				gli=new GlacialComponents.Controls.GLItem();
				for(int j=0;j<myData.MapWidth;j++)
				{
					gls=new GlacialComponents.Controls.GLSubItem();
					if(j==0) 
					{
						gls.Text=i.ToString();
						gls.BackColor=System.Drawing.Color.LightGray;
					}
					gli.SubItems.Add(gls);
				}
				this.glMap.Items.Add(gli);
			}
			//add all rooms to map
			int row,column,currentid;
			foreach(Room MapRoom in myData.Rooms)
			{
				currentid=MapRoom.ActualRoomID;
				column=currentid%myData.MapWidth;
				if(currentid<myData.MapWidth) row=0;
				else row=(currentid-column)/myData.MapWidth;

				//translate other way round
				row=(glMap.Items.Count-1)-row;	//start from bottom
				column++;	//ignore column 0 as its the title
				glMap.Items[row].SubItems[column].BackColor=System.Drawing.Color.IndianRed;
				if(myData.Prefixname=="kl")
				{
					if(MapRoom.ActualRoomID==47 || MapRoom.ActualRoomID==68 || MapRoom.ActualRoomID==179 || MapRoom.ActualRoomID==143)
						glMap.Items[row].SubItems[column].BackColor=System.Drawing.Color.Purple;
				}
				if(myData.Prefixname=="a8")
				{
					if(MapRoom.ActualRoomID==19 || MapRoom.ActualRoomID==78 || MapRoom.ActualRoomID==136 || MapRoom.ActualRoomID==215)
						glMap.Items[row].SubItems[column].BackColor=System.Drawing.Color.Purple;
				}
				glMap.Items[row].SubItems[column].Tag=MapRoom.ActualRoomID;
			}
			this.glMap.Refresh();
			if(this.ListboxRooms.Items.Count>0) this.UpdateItem();
		}

		private bool DisplayOutputToText(string filetoload)
		{
			outputwindow mywindow=new outputwindow();
			if(mywindow.LoadData(filetoload))
				mywindow.ShowDialog(this);
			return true;
		}

		private void glMap_ItemChangedEvent(object source, GlacialComponents.Controls.ChangedEventArgs e)
		{
			try
			{
				DrawPurples();
				if(LastItemElement!=null)
					LastItemElement.BackColor=Color.IndianRed;
				

				if(LastItem!=null && e.ChangedType==GlacialComponents.Controls.ChangedTypes.ItemChanged && e.SubItem.Tag.ToString()!=LastItem)
				{
					//MessageBox.Show(this,e.SubItem.Tag.ToString());
					e.SubItem.BackColor=Color.YellowGreen;
					LastItem=e.SubItem.Tag.ToString();
					LastItemElement=e.SubItem;
					try 
					{
						this.ListboxRooms.SelectedIndex=this.ListboxRooms.FindString("Room " +LastItem);
						e.SubItem.BackColor=Color.YellowGreen;
//						this.glMap.Refresh();
					} 
					catch 
					{
						MessageBox.Show(this,"Room " + LastItem+" could not be found!");
					}
				}
			}
			catch
			{
				//more than likely clicking an empty room. ignore
			}
		}

		private void RadioDebug_Click(object sender, System.EventArgs e)
		{
			DisplayOutputToText("outputs\\"+myData.Prefixname+"_debuglog.txt");
		}

		private void RadioRaw_Click(object sender, System.EventArgs e)
		{
			DisplayOutputToText("outputs\\"+myData.Prefixname+"_rawstructure.txt");
		}

		private void RadioIsoCis_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show(this,"Not done yet");
		}

		private void RadioXML_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show(this,"Use a browser or other application to view the XML file using the pre-defined XML template or the pre-defined XML schema.");
			DisplayOutputToText("outputs\\"+myData.Prefixname+"_xml.xml");
		}

		private void ButtonAddRow_Click(object sender, System.EventArgs e)
		{
			objectdetails AddForm=new objectdetails();
			Room lRoom=(Room)myData.Rooms[this.ListboxRooms.SelectedIndex];
			AddForm.InitialiseData(myData,lRoom,"",false);
			AddForm.ShowDialog(this);

			string BlockName=AddForm.BlockName;
			int X=AddForm.XPosition;
			int Y=AddForm.YPosition;
			int Z=AddForm.ZPosition;

			AddForm.Close();

			//process data
			if(AddForm.Tag.ToString()!="")
			{
				//add it
				Block NewBlock=new Block();
				//find block type
				BlockDescriptor BlockType=myData.FindBlockFromString(1,BlockName);
				if(BlockType.Number==-1)
					MessageBox.Show(this,"Item somehow not found in the system! Must be an error somewhere. Item not added");
				else
				{
					//adjust z if this block is an offset (knight lore)
					int NewZ=AddForm.ZPosition;
					if((BlockType.Offsetxyz>>2)!=0)
					{
						//offset
						int Zoff=BlockType.Offsetxyz>>2;
						NewZ=NewZ-((Zoff*4)/12);
					}
					//update block (actual byte not required) and add location to it
					NewBlock.Type=BlockType.Number;
					BlockLocation NewLocation=new BlockLocation(0,AddForm.XPosition,AddForm.YPosition,NewZ);
					NewBlock.BlockLocations.Add(NewLocation);
					//now the hard bit of adding it
					//need to see if the block exists for the room first
					// if not then add as a new room block
					// if it does and it has <8 locations add the location only to this
					// if more then add as a new block (unless there are more with <8 locations
					bool bAdded=false;
					foreach(Block tBlock in lRoom.ForegroundItems)
					{
						if(tBlock.Type==NewBlock.Type && tBlock.BlockLocations.Count<8)
						{
							//a match
							tBlock.BlockLocations.Add(NewLocation);
							bAdded=true;
							break;
						}
					}
					if(!bAdded)
					{
						lRoom.ForegroundItems.Add(NewBlock);
					}
				}
				//update display
				RefreshRequired=true;
				EditDirty=true;
				UpdateSize();
				RoomChange();
			}
		}

		private void ButtonDeleteRow_Click(object sender, System.EventArgs e)
		{
			//index and room in list
			if(glList.SelectedIndicies.Count<1) return;
			int CurrentRow=(int)glList.SelectedIndicies[0];
			Room lRoom=(Room)myData.Rooms[this.ListboxRooms.SelectedIndex];

			GlacialComponents.Controls.GLItem gli=((GlacialComponents.Controls.GLItem)glList.Items[CurrentRow]);
			if(gli.SubItems[10].Text=="") MessageBox.Show("Can only delete room items");
			else
			{
				int BlockIndex=Convert.ToInt32(gli.SubItems[10].Text);
				int LocationIndex=Convert.ToInt32(gli.SubItems[11].Text);
				((Block)(lRoom.ForegroundItems[BlockIndex])).BlockLocations.RemoveAt(LocationIndex);
				if( ((Block)(lRoom.ForegroundItems[BlockIndex])).BlockLocations.Count==0)
					lRoom.ForegroundItems.RemoveAt(BlockIndex);
				RefreshRequired=true;
				EditDirty=true;
				UpdateSize();
				RoomChange();
			}
		}

		private void EditRow_Click(object sender, System.EventArgs e)
		{
			//index and room in list
			if(glList.SelectedIndicies.Count<1) return;
			int CurrentRow=(int)glList.SelectedIndicies[0];
			GlacialComponents.Controls.GLItem gli=((GlacialComponents.Controls.GLItem)glList.Items[CurrentRow]);

			if(gli.SubItems[10].Text=="") MessageBox.Show("Can only edit room items");
			else
			{
				int LocationIndex=Convert.ToInt32(gli.SubItems[11].Text);
				Room lRoom=(Room)myData.Rooms[this.ListboxRooms.SelectedIndex];
				int BlockIndex=Convert.ToInt32(gli.SubItems[10].Text);

				int x=Convert.ToInt32(gli.SubItems[2].Text);
				int y=Convert.ToInt32(gli.SubItems[3].Text);
				int z=Convert.ToInt32(gli.SubItems[4].Text);
				bool xoff=(gli.SubItems[5].Text!="");
				bool yoff=(gli.SubItems[6].Text!="");

				//six is irrelevant as not used in alien8 and block determines z offset in knight lore
				objectdetails AddForm=new objectdetails();
				AddForm.InitialiseData(myData,(Room)myData.Rooms[this.ListboxRooms.SelectedIndex],gli.SubItems[1].Text,true,x,y,z,xoff,yoff);
				AddForm.ShowDialog(this);

				//process data
				if(AddForm.Tag.ToString()!="")
				{
					//update it
					BlockLocation bl=((BlockLocation)((Block)(lRoom.ForegroundItems[BlockIndex])).BlockLocations[LocationIndex]);

					bl.x=AddForm.XPosition;
					bl.y=AddForm.YPosition;
					bl.z=AddForm.ZPosition;

					BlockDescriptor BlockType=myData.FindBlockFromNumber(1,((Block)(lRoom.ForegroundItems[BlockIndex])).Type);
					if(BlockType.Number==-1)
						MessageBox.Show(this,"Item somehow not found in the system! Must be an error somewhere. Item not added properly, the system will probably crash horribly :)");
					else
					{
						//adjust z if this block is an offset (knight lore)
						int NewZ=bl.z;
						if((BlockType.Offsetxyz>>2)!=0)
						{
							//offset
							int Zoff=BlockType.Offsetxyz>>2;
							NewZ=NewZ-((Zoff*4)/12);
							bl.z=NewZ;
						}
					}
					//update display
					RefreshRequired=true;
					EditDirty=true;
					UpdateSize();
					RoomChange();
				}
				AddForm.Close();
			}
		}


		private void ButtonRefresh_Click(object sender, System.EventArgs e)
		{
			int size=myData.GenerateLocationData();
			this.RefreshRequired=false;
			this.EditDirty=false;
			this.UpdateSize();
		}

		private void ButtonCreateGame_Click(object sender, System.EventArgs e)
		{
			if(myData.Prefixname!="kl" && myData.Prefixname!="a8")
			{
				MessageBox.Show(this,"Unknown game type, cannot create game. It isn't knight lore or alien 8");
				return;
			}

			int size=myData.GenerateLocationData();
			this.RefreshRequired=false;
			this.UpdateSize();
			MessageBox.Show(this,"Map File Saved. "+size.ToString()+" bytes written");
			this.EditDirty=false;
			if(myData.CurrentLocationDataSize>myData.OriginalLocationDataSize)
			{
				if(MessageBox.Show("You are about to write more data than in the original game! Doing so will more than likely crash the game. Do you wish to continue?","Continue?",MessageBoxButtons.YesNo)==DialogResult.No)
					return;
			}

			if(!System.IO.File.Exists("maps\\"+myData.Prefixname+".sna"))
				MessageBox.Show(this,"The original snapshot: " + "maps\\"+myData.Prefixname+".sna"+" does not exist! cannot create new game :(");
			else
			{
				//snapshot only supported as cannot guarantee z80 will not be compressed and cannot be arsed
				//to write a compression routine that probably will be bug ridden ;)

				//bytes 0-26 are header stuff
				//bytes 27 onwards is the memory dump
				//so location data for knight lore starts at 0x6251 and alien 8 at 0x6469
				int byteoffset=0;
				int messageoffset=0;
				switch(myData.Prefixname)
				{
					case "kl":
						byteoffset=0x6251;
						messageoffset=0x7e41;
						break;
					case "a8":
						byteoffset=0x6469;
						messageoffset=0x7bad;
						break;
				}
				if(byteoffset==0) MessageBox.Show(this,"Error, '"+byteoffset.ToString()+"' is not a know game type! must be 'kl' or 'a8' - game not written");
				else
				{
					char[] bob2=",".ToCharArray();
					string lineread;
					string dest="outputs\\"+myData.Prefixname+"_"+myData.AdditionalLocation+".sna";
					string orig="maps\\"+myData.Prefixname+".sna";
					File.Copy(orig,dest,true);
					byteoffset-=16384;	//start of memory
					byteoffset+=27;		//offset for file header

					//get the data to write
					StreamReader sr=new StreamReader("maps\\"+myData.Prefixname+"_map_user.txt");
					bool MapOk=false;
					while((lineread=sr.ReadLine()) !=null)
					{
						string[] LocationDataString=lineread.Split(bob2);
						if(LocationDataString[0]==myData.AdditionalLocation)
						{
							FileStream fsMap=new FileStream(dest,FileMode.Open,FileAccess.ReadWrite);
							BinaryWriter bw=new BinaryWriter(fsMap);
							bw.Seek(byteoffset,SeekOrigin.Begin);

							int i=0;
							foreach(string element in LocationDataString)
							{
								if(element!=myData.AdditionalLocation) 
									bw.Write(Convert.ToByte(element,16));

								i++;
							}

							//write menu to show its not the real one
							byte[] tmp;
							bw.Seek(messageoffset,SeekOrigin.Begin);
							if(myData.Prefixname=="kl")
								tmp=new byte [] {0x2,0x0,0x0,0x4,0x26,0x1b,0x0e,0x1d,0x1b,0x18};
							else
								//tmp=new byte [] {0x031,0x039,0x038,0x035,0x020,0x041,0x03B,0x043,0x03B,0x047,0x0BB};
								tmp=new byte[] {0x32,0x30,0x30,0x34,0x20,0x52,0x45,0x54,0x52,0x4f};

							bw.Write(tmp);
							bw.Close();
							MapOk=true;
							break;
						}
					}
					sr.Close();
					if(MapOk) MessageBox.Show(this,dest+" has been written. Happy gaming :)");
					else MessageBox.Show(this,"Game not written because the map was no longer found!");
				}
			}
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(!CheckSave()) e.Cancel=true;
		}
	}
}
