The files required are :

name            size
INVADERS.E      2048
INVADERS.F      2048
INVADERS.G      2048
INVADERS.H      2048

/MikeJ
