#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <math.h>
#include <iostream>
using namespace std;

#define MAX_ROM_SIZE 0x4000

int main(int argc, char* argv[])

{
	cerr << "romgen by MikeJ version 1.01\n";
	// read file

	string buffer;
	FILE *fin;

	if(argc != 6)
	{		
		cerr << "\nUsage: romgen <input file> <entity name> <number of address bits>\n";
		cerr << "                  <format> <registered>\n";
		cerr << "\n";
		cerr << "for the format paramater use :\n";
		cerr << "  a  - rtl model rom array \n";
		cerr << "  c  - rtl model case statement \n";
		cerr << "  b  - Xilinx block ram (registered output always)\n";
		cerr << "  d  - Xilinx distributed ram [not supported yet]\n";
		cerr << "\n";
		cerr << "for the registered paramater use :\n";
		cerr << "  c  - combinatorial output \n";
		cerr << "  r  - registered output \n";
		cerr << "\n";
		cerr << "note, generated roms are always 8 bits wide\n";
		cerr << "      max 12 address bits for block rams\n";
		cerr << "for example romgen fred.bin fred_rom 12 c r\n\n";
		return -1;
	}

	fin = fopen(argv[1],"rb");
	if (fin == NULL) {
	  cerr << "ERROR : Could not open input file " << argv[1] <<"\n";
	  return -1;
	}

    char rom_type = 0;
	char output_type = 0;
	sscanf(argv[4],"%c",&rom_type);
	sscanf(argv[5],"%c",&output_type);

	bool format_case = false;
	bool format_array = false;
	bool format_block = false;
	bool format_dist = false;
	bool format_clock = false;

	cerr << "INFO : creating entity : " << argv[2] << "\n";

	if ((output_type == 'c') || (output_type == 'C')) {
		format_clock = false; }
	else if ((output_type == 'r') || (output_type == 'R')) {
		format_clock = true; }
	else {
	  cerr << "ERROR : output option not supported\n";
	  return -1;
	}

	if ((rom_type == 'c') || (rom_type == 'C')) {
		cerr << "INFO : rtl model, case statement \n"; format_case = true; }
	else if ((rom_type == 'a') || (rom_type == 'A')) {
		cerr << "INFO : rtl model, rom array \n"; format_array = true; }
	else if ((rom_type == 'b') || (rom_type == 'B')) {
		cerr << "INFO : block ram, registered \n"; format_block = true; format_clock = true; }
	//else if ((rom_type == 'd') || (rom_type == 'D')) {
	//  cerr << "INFO : distributed ram, combinatoria; \n"; format_dist = true; }
	else {
	  cerr << "ERROR : format not supported\n";
	  return -1;
	}
	if (format_clock == true)
		cerr << "INFO : registered output\n\n";
	else
		cerr << "INFO : combinatorial output\n\n";


	// calc number of address bits required
	int addr_bits;
	sscanf(argv[3],"%d",&addr_bits);
	if (addr_bits < 1 || addr_bits > 12 && (format_block == true)) {
	  cerr << "ERROR : illegal rom size, number of address bits must be between 1 and 12\n";
	  return -1;
	}
	// for  12 bits use ram_b4_s1 x data_width
	// for  11 bits use ram_b4_s2 x data_width/2
	// for  10 bits use ram_b4_s4 x data_width/4
	// for <=9 bits use ram_b4_s8 x data_width/8
	int rom_size = pow(2,addr_bits);

	int number_of_block_rams = 1;
	int block_ram_width = 8;
	int block_ram_abits = 9;

	switch (addr_bits) {
	 case 12 : number_of_block_rams = 8; block_ram_width = 1; block_ram_abits = 12; break;
	 case 11 : number_of_block_rams = 4; block_ram_width = 2; block_ram_abits = 11; break;
	 case 10 : number_of_block_rams = 2; block_ram_width = 4; block_ram_abits = 10; break;
	 default : ;
	}

	//printf("block ram w : %d ",block_ram_width);
	//printf("block ram n : %d ",number_of_block_rams);

	
	// process
	int mem[MAX_ROM_SIZE];
	string line;

	int i,j,k;


	int addr = 0;
	int offset = 0;
	int mask = 0;
	unsigned int data = 0;

	// clear mem
	for (i = 0; i < MAX_ROM_SIZE; i++) mem[i] = 0;

	// process file
	data = getc(fin);
	while (!feof(fin)) {
	  if (addr >= MAX_ROM_SIZE) {
		cerr << "ERROR : file too large\n";
		return -1;
	  }

	  mem[addr] = data;
	  // debug
	  //if (addr % 16 == 0) printf("%04x : ",addr);
	  //printf("%02x  ",data);
	  //if (addr % 16 == 15) printf("\n");
	  // end debug
	  addr ++;
	  data = getc(fin);
	}
	fclose(fin);


	printf("-- generated with romgen by MikeJ\n");
	printf("library ieee;\n");
	printf("use ieee.std_logic_1164.all;\n");
	printf("use ieee.numeric_std.all;\n");
	printf("\n");
	printf("entity %s is\n",argv[2]);
	printf("  port (\n");
	if (format_clock == true) printf("    CLK         : in    std_logic;\n");
	printf("    ADDR        : in    std_logic_vector(%d downto 0);\n",addr_bits - 1);
	printf("    DATA        : out   std_logic_vector(7 downto 0)\n");
	printf("    );\n");
	printf("end;\n");
	printf("\n");
	printf("architecture RTL of %s is\n",argv[2]);
	printf("\n");

	// if blockram
	if (format_block == true) {
	  printf("  function romgen_str2slv (str : string) return std_logic_vector is\n");
	  printf("    variable result : std_logic_vector (str'length*4-1 downto 0);\n");
	  printf("  begin\n");
	  printf("    for i in 0 to str'length-1 loop\n");
	  printf("      case str(str'high-i) is\n");
	  for (i = 0; i<16; i++)
		printf("        when '%01X'       => result(i*4+3 downto i*4) := x\042%01X\042;\n",i,i);
	  printf("        when others => result(i*4+3 downto i*4) := \042XXXX\042;\n");
	  printf("      end case;\n");
	  printf("    end loop;\n");
	  printf("    return result;\n");
	  printf("  end romgen_str2slv;\n");
	  printf("\n");

	  // xilinx block ram component
	  for (i = 0; i<16; i++)
		printf("  attribute INIT_%02X : string;\n",i);
	  printf("\n");
	  printf("  component RAMB4_S%d\n",block_ram_width);
	  printf("    --pragma translate_off\n");
	  printf("    generic (\n");
	  for (i = 0; i<16; i++) {
		printf("      INIT_%02X : std_logic_vector (255 downto 0) := x\0420000000000000000000000000000000000000000000000000000000000000000\042",i);
		if (i<15) printf(";");
		printf("\n");
	  }
	  printf("      );\n");
	  printf("    --pragma translate_on\n");
	  printf("    port (\n");
	  printf("      DO    : out std_logic_vector (%d downto 0);\n",block_ram_width -1);
	  printf("      DI    : in  std_logic_vector (%d downto 0);\n",block_ram_width -1);
	  printf("      ADDR  : in  std_logic_vector (%d downto 0);\n",block_ram_abits -1);
	  printf("      WE    : in  std_logic;\n");
	  printf("      EN    : in  std_logic;\n");
	  printf("      RST   : in  std_logic;\n");
	  printf("      CLK   : in  std_logic \n");
	  printf("      );\n");
	  printf("  end component;\n");
	  printf("\n");
	  printf("  signal rom_addr : std_logic_vector(%d downto 0);\n",block_ram_abits - 1);
	  printf("\n");
	}

	if (format_array == true) {
	  printf("\n");
	  printf("  type ROM_ARRAY is array(0 to %d) of std_logic_vector(7 downto 0);\n",rom_size - 1);
	  printf("  constant ROM : ROM_ARRAY := (\n");
	  for (i = 0; i < rom_size; i ++ ) {
		if (i % 8 == 0) printf("    ");
		printf("x\042%02X\042",mem[i]);
		if (i  < (rom_size - 1)) printf(",");
		if (i == (rom_size - 1)) printf(" ");
		if (i % 8 == 7) printf(" -- 0x%04X\n",i - 7);
	  }
	  printf("  );\n");
	  printf("\n");
	} // end array

	if (format_case == true) {
	  printf("  signal rom_addr : std_logic_vector(11 downto 0);\n");
	  printf("\n");
	}

	printf("begin\n");
	printf("\n");
	//
	if ((format_block == true) || (format_case == true)) {
	  printf("  p_addr : process(ADDR)\n");
	  printf("  begin\n");
	  printf("     rom_addr <= (others => '0');\n");
	  printf("     rom_addr(%d downto 0) <= ADDR;\n",addr_bits - 1);
	  printf("  end process;\n");
	  printf("\n");
	}
	//
	if (format_block == true) {
	  for (k = 0; k < number_of_block_rams; k ++){
		printf("  rom%d : if true generate\n",k);

		for (j = 0; j < 16; j++) {
		  printf("    attribute INIT_%02X of inst : label is \042",j);
		  switch (block_ram_width) {

		  case 1 : // width 1
		  mask = 0x1 << (k);
		  for (i = 0; i < 256; i+=8) {
			data  = ((mem[(j*256) + (255 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (254 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (253 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (252 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (251 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (250 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (249 - i)] & mask) >> k);
			data <<= 1;
			data += ((mem[(j*256) + (248 - i)] & mask) >> k);
			printf("%02X",data);
		  }
		  break;

		  case 2 : // width 2
		  mask = 0x3 << (k * 2);
		  for (i = 0; i < 128; i+=4) {
			data  = ((mem[(j*128) + (127 - i)] & mask) >> k * 2);
			data <<= 2;
			data += ((mem[(j*128) + (126 - i)] & mask) >> k * 2);
			data <<= 2;
			data += ((mem[(j*128) + (125 - i)] & mask) >> k * 2);
			data <<= 2;
			data += ((mem[(j*128) + (124 - i)] & mask) >> k * 2);
			printf("%02X",data);
		  }
		  break;

		  case 4 : // width 4
		  mask = 0xF << (k * 4);
		  for (i = 0; i < 64; i+=2) {
			data  = ((mem[(j*64) + (63 - i)] & mask) >> k * 4);
			data <<= 4;
			data += ((mem[(j*64) + (62 - i)] & mask) >> k * 4);

			printf("%02X",data);
		  }
		  break;


		  case 8 : // width 8
		  for (i = 0; i < 32; i++) {
			data = ((mem[(j*32) + (31 - i)]));
			printf("%02X",data);
		  }
		  break;
		  } // end switch

		  printf("\042;\n");
		}

		printf("  begin\n");
		printf("    inst : ramb4_s%d\n",block_ram_width);
		printf("      --pragma translate_off\n");
		printf("      generic map (\n");
		for (i = 0; i<16; i++) {
		  printf("        INIT_%02X => romgen_str2slv(inst'INIT_%02X)",i,i);
		  if (i<15) printf(",");
		  printf("\n");
		}
		printf("        )\n");
		printf("      --pragma translate_on\n");
		printf("      port map (\n");
		printf("        DO   => DATA(%d downto %d),\n",((k+1) * block_ram_width)-1,k*block_ram_width);
		printf("        DI   => \042");
		  for (i = 0; i < block_ram_width -1; i++) printf("0");
		printf("0\042,\n");
		printf("        ADDR => rom_addr,\n");
		printf("        WE   => '0',\n");
		printf("        EN   => '1',\n");
		printf("        RST  => '0',\n");
		printf("        CLK  => CLK\n");
		printf("        );\n");
		printf("  end generate;\n");
	  }
	} // end block ram

	if (format_array == true) {
	  if (format_clock == true)
		printf("  p_rom : process\n");
	  else
		printf("  p_rom : process(ADDR)\n");
	  printf("  begin\n");
	  if (format_clock == true)
		printf("    wait until rising_edge(CLK);\n");
	  printf("     DATA <= ROM(to_integer(unsigned(ADDR)));\n");
	  printf("  end process;\n");
	} // end array

	if (format_case == true) {
	  if (format_clock == true)
		printf("  p_rom : process\n");
	  else
		printf("  p_rom : process(rom_addr)\n");
	  printf("  begin\n");
	  if (format_clock == true)
		printf("    wait until rising_edge(CLK);\n");
	  printf("    DATA <= (others => '0');\n");
	  printf("    case rom_addr is\n");
	  for (i = 0; i < rom_size; i ++ ) {
		printf("      when x\042%03X\042 => DATA <= x\042%02X\042;\n",i,mem[i]);
	  }
	  printf("      when others => DATA <= (others => '0');\n");
	  printf("    end case;\n");
	  printf("  end process;\n");
	} // end case
	printf("end RTL;\n");

	return 0;
}
