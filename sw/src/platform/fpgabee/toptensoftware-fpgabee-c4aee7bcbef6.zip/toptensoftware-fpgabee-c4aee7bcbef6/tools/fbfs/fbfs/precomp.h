#ifndef _PRECOMP_H
#define _PRECOMP_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <tchar.h>
#include "dirent.h"

#include "SimpleLib.h"

using namespace Simple;

#ifdef _WIN32
#include <io.h>
#include <windows.h>
#endif

#endif