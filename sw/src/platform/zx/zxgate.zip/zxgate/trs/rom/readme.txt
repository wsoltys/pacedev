The synthesis and simulation scipts expects to find the
trs80 ROMs in this directory with the following file names:

level1.bin
level2.bin

For simulation you must also run rtl/gen_roms.bat
