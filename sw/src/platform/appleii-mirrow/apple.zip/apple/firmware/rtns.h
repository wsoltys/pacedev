#ifndef __RTNS_H__
#define __RTNS_H__

#include "cfg.h"

/* ------------------------------------------------------------------------- */

#if defined (AVR)
#define rtns_get_u16le(p) *(uint16 *)(p)
#define rtns_get_u32le(p) *(uint32 *)(p)
#else
uint rtns_get_u16le (void *p);
uint32 rtns_get_u32le (void *p);
#endif

#endif
