/* Computes checksums of an Atari 400/800 OS ROM image and writes a modified image back. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

enum { ROM_SIZE= 0x2800 };

int main(int argc, char *argv[])
{
	FILE *f;
	unsigned char rom[ROM_SIZE];
	unsigned int length;
	unsigned int i;
	unsigned int sum;
	if (argc < 4) {
		fprintf(stderr, " Usage: %s <antsc|apal|bntsc|bpal> <input filename> <output filename>\n", argv[0]);
		return EXIT_FAILURE;
	}

	/* Read ROM image. */
	f = fopen(argv[2], "rb");
	if (f == NULL) {
		fprintf(stderr, "Can't open %s\n", argv[2]);
		return EXIT_FAILURE;
	}
	if (fread(rom, sizeof(char), ROM_SIZE, f) != ROM_SIZE) {
		fprintf(stderr, "Can't read %s or file length not equal to %04x bytes\n", argv[2], ROM_SIZE);
		return EXIT_FAILURE;
	}
	if (fclose(f) != 0) {
		fprintf(stderr, "Can't close %s\n", argv[2]);
		return EXIT_FAILURE;
	}

	/* Checksum of FPP ROM. */
	sum = 0;
	for (i = 0x0000; i < 0x07fe; ++i)
		sum += rom[i];
	sum &= 0xffff;
	rom[0x07fe] = sum & 0xff;
	rom[0x07ff] = sum >> 8;

	if (strcmp(argv[1], "antsc") == 0 ||
	    strcmp(argv[1], "apal") == 0 ||
	    strcmp(argv[1], "bpal") == 0) {
		/* Checksum of first 4K ROM. */
		sum = 0;
		for (i = 0x0800; i < 0x0c0f; ++i)
			sum += rom[i];
		for (i = 0x0c10; i < 0x0c1f; ++i)
			sum += rom[i];
		for (i = 0x0c20; i < 0x1800; ++i)
			sum += rom[i];
		sum &= 0xffff;
		rom[0x0c0f] = sum & 0xff;
		rom[0x0c1f] = sum >> 8;

		/* Checksum of second 4K ROM. */
		sum = 0;
		for (i = 0x1800; i < 0x27f8; ++i)
			sum += rom[i];
		for (i = 0x27fa; i < 0x2800; ++i)
			sum += rom[i];
		sum &= 0xffff;
		rom[0x27f8] = sum & 0xff;
		rom[0x27f9] = sum >> 8;
	}

	/* Save modified rom image. */
	f = fopen(argv[3], "wb");
	if (f == NULL) {
		fprintf(stderr, "Can't open %s\n", argv[3]);
		return EXIT_FAILURE;
	}
	if (fwrite(rom, sizeof(char), ROM_SIZE, f) != ROM_SIZE) {
		fprintf(stderr, "Can't write %s\n", argv[3]);
		return EXIT_FAILURE;
	}
	if (fclose(f) != 0) {
		fprintf(stderr, "Can't close %s\n", argv[3]);
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
