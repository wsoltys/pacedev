/* Computes checksums of an Atari XL OS ROM image and writes a modified image back. */

#include <stdlib.h>
#include <stdio.h>

enum { ROM_SIZE= 0x4000 };

int main(int argc, char *argv[])
{
	FILE *f;
	unsigned char rom[ROM_SIZE];
	unsigned int length;
	unsigned int i;
	unsigned int sum;
	if (argc < 3) {
		fprintf(stderr, " Usage: %s <input filename> <output filename>\n", argv[0]);
		return EXIT_FAILURE;
	}

	/* Read ROM image. */
	f = fopen(argv[1], "rb");
	if (f == NULL) {
		fprintf(stderr, "Can't open %s\n", argv[1]);
		return EXIT_FAILURE;
	}
	if (fread(rom, sizeof(char), ROM_SIZE, f) != ROM_SIZE) {
		fprintf(stderr, "Can't read %s or file length not equal to %04x bytes\n", argv[1], ROM_SIZE);
		return EXIT_FAILURE;
	}
	if (fclose(f) != 0) {
		fprintf(stderr, "Can't close %s\n", argv[1]);
		return EXIT_FAILURE;
	}

	/* Checksum of first 8K ROM. */
	sum = 0;
	for (i = 0x0002; i < 0x2000; ++i)
		sum += rom[i];
	sum &= 0xffff;
	rom[0x0000] = sum & 0xff;
	rom[0x0001] = sum >> 8;

	/* Checksum of second 8K ROM. */
	sum = 0;
	for (i = 0x2000; i < 0x3ff8; ++i)
		sum += rom[i];
	for (i = 0x3ffa; i < 0x4000; ++i)
		sum += rom[i];
	sum &= 0xffff;
	rom[0x3ff8] = sum & 0xff;
	rom[0x3ff9] = sum >> 8;

	/* Save modified rom image. */
	f = fopen(argv[2], "wb");
	if (f == NULL) {
		fprintf(stderr, "Can't open %s\n", argv[2]);
		return EXIT_FAILURE;
	}
	if (fwrite(rom, sizeof(char), ROM_SIZE, f) != ROM_SIZE) {
		fprintf(stderr, "Can't write %s\n", argv[2]);
		return EXIT_FAILURE;
	}
	if (fclose(f) != 0) {
		fprintf(stderr, "Can't close %s\n", argv[2]);
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
